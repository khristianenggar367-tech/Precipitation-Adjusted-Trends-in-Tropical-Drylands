# -*- coding: utf-8 -*-
"""
MAST — Mann-Kendall And Sen's Slope Trend Analyzer
====================================================
Version     : 1.0.0
QGIS        : 4.0+ (Qt6 / PyQt6 / Python 3.12)
Author      : [ANONYMIZED FOR PEER REVIEW]
E-mail      : [ANONYMIZED FOR PEER REVIEW]
Institution : [ANONYMIZED FOR PEER REVIEW]
Repository  : [ANONYMIZED FOR PEER REVIEW]

Description
-----------
MAST performs pixel-wise non-parametric Mann-Kendall monotonic trend
tests on multi-temporal raster stacks and estimates the magnitude of
change using the Theil–Sen slope estimator (Sen's slope).

Output rasters
--------------
  trend_map_zscore.tif  –  Mann-Kendall Z-score  (−∞ … +∞, float32)
  p_value.tif           –  Two-tailed p-value     (0 … 1,   float32)
  sens_slope.tif        –  Sen's slope            (units yr⁻¹, float32)
  total_change.tif      –  Last − First value     (float32)
  statistics.json       –  Full summary report

References
----------
Mann, H. B. (1945). Nonparametric tests against trend.
    Econometrica, 13(3), 245–259.
Kendall, M. G. (1975). Rank Correlation Methods (4th ed.).
    Charles Griffin, London.
Sen, P. K. (1968). Estimates of the regression coefficient based on
    Kendall's tau. Journal of the American Statistical Association,
    63(324), 1379–1389.
Theil, H. (1950). A rank-invariant method of linear and polynomial
    regression analysis. Proceedings of the Royal Netherlands Academy
    of Arts and Sciences, 53, 386–392.
"""

# ── Standard library ──────────────────────────────────────────────────────────
import os
import json
import traceback

# ── QGIS / PyQt6 ─────────────────────────────────────────────────────────────
from qgis.PyQt.QtCore import QCoreApplication, Qt
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QListWidget,
    QProgressBar, QTextEdit, QGroupBox, QCheckBox,
    QFileDialog, QMessageBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView,
    QInputDialog, QComboBox,
)
from qgis.PyQt.QtGui import QFont, QIcon
from qgis.core import (
    QgsRasterLayer, QgsProject, QgsMessageLog, Qgis,
    QgsColorRampShader, QgsSingleBandPseudoColorRenderer,
    QgsRasterShader,
)
from qgis.PyQt.QtGui import QColor

# ── Numerical / spatial ───────────────────────────────────────────────────────
import numpy as np
from osgeo import gdal, osr

# ── Optional scientific stack ─────────────────────────────────────────────────
try:
    from scipy import stats

    import matplotlib
    try:
        matplotlib.use('qtagg')           # Qt-version-agnostic backend (Qt6)
    except Exception:
        pass                              # Already set elsewhere – ignore

    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg

    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False

# ── Plugin constants ──────────────────────────────────────────────────────────
PLUGIN_NAME    : str   = "MAST"
PLUGIN_TITLE   : str   = "Mann-Kendall And Sen's Slope Trend Analyzer"
PLUGIN_VERSION : str   = "1.0.0"
NODATA_VALUE   : float = -9999.0       # Sentinel for all output rasters


# =============================================================================
#  STATISTICAL CORE
# =============================================================================

def mann_kendall_test(data: np.ndarray,
                      correct_variance: bool = False) -> tuple:
    """
    Non-parametric Mann-Kendall monotonic trend test.

    Parameters
    ----------
    data : 1-D array-like
        Temporally ordered observations for a single pixel.
    correct_variance : bool, optional
        If True, applies the Hamed & Rao (1998) variance correction
        to account for serial autocorrelation in the time series.
        Recommended when n ≥ 4 and the data may be autocorrelated.
        Default: False (standard ties-free formula).

    Returns
    -------
    trend : str
        'increasing' | 'decreasing' | 'no trend'  (α = 0.05)
    p_value : float
        Two-tailed probability under H₀ (no monotonic trend).
    z_score : float
        Continuity-corrected standard normal statistic.
        Used directly as the trend map pixel value.
    tau : float
        Kendall's rank correlation coefficient.
    lag1_acf : float
        Lag-1 Spearman rank autocorrelation of the series.
        NaN when correct_variance is False.

    Notes
    -----
    Standard formula assumes no ties; the continuity correction
    (±1 before division) improves accuracy for small n.

    When correct_variance=True, Var(S) is multiplied by the
    Hamed & Rao (1998) inflation factor derived from all lag-k
    Spearman rank correlations. This reduces spurious significance
    under positive autocorrelation at the cost of slightly reduced
    power against genuine trends.

    References
    ----------
    Hamed, K. H., & Rao, A. R. (1998). A modified Mann-Kendall trend
        test for autocorrelated data. Journal of Hydrology, 204, 182–196.
        https://doi.org/10.1016/S0022-1694(97)00125-X
    """
    n = len(data)

    # S statistic — counts concordant minus discordant pairs
    s = 0.0
    for i in range(n - 1):
        for j in range(i + 1, n):
            s += np.sign(data[j] - data[i])

    # Theoretical variance of S under H₀ (no-ties formula)
    var_s = n * (n - 1) * (2 * n + 5) / 18.0

    # ── Optional Hamed & Rao (1998) autocorrelation correction ───────────
    lag1_acf = float('nan')
    if correct_variance and n >= 4:
        inflation = _hamed_rao_inflation(data)
        var_s    *= inflation
        lag1_acf  = compute_lag1_autocorr(data)

    # Continuity-corrected Z statistic
    if s > 0:
        z = (s - 1.0) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1.0) / np.sqrt(var_s)
    else:
        z = 0.0

    # Two-tailed p-value from the standard normal distribution
    p_value = 2.0 * (1.0 - stats.norm.cdf(abs(z)))

    # Kendall's τ (normalised S)
    tau = s / (0.5 * n * (n - 1))

    # Trend classification at α = 0.05
    if p_value < 0.05:
        trend = 'increasing' if s > 0 else 'decreasing'
    else:
        trend = 'no trend'

    return trend, p_value, z, tau, lag1_acf


def sens_slope(data: np.ndarray, years: list) -> tuple:
    """
    Theil–Sen robust slope estimator.

    Computes the median of all pairwise slopes between observations,
    providing a resistant estimate of the linear rate of change.

    Parameters
    ----------
    data  : 1-D array-like – observations in temporal order.
    years : list of int    – corresponding year labels.

    Returns
    -------
    slope     : float – median pairwise slope (units yr⁻¹).
    intercept : float – corresponding median intercept.

    References
    ----------
    Sen (1968); Theil (1950).
    """
    n = len(data)
    slopes = []

    for i in range(n - 1):
        for j in range(i + 1, n):
            dt = years[j] - years[i]
            if dt != 0:
                slopes.append((data[j] - data[i]) / dt)

    if not slopes:
        return 0.0, float(data[0])

    slope     = float(np.median(slopes))
    intercept = float(np.median(
        [data[i] - slope * years[i] for i in range(n)]))

    return slope, intercept


def compute_lag1_autocorr(data: np.ndarray) -> float:
    """
    Lag-1 Spearman rank autocorrelation of a time series.

    Rank-based (non-parametric) estimator, consistent with the
    Mann-Kendall framework and robust to outliers.

    Parameters
    ----------
    data : 1-D array-like
        Temporally ordered observations (minimum length 3).

    Returns
    -------
    float
        Lag-1 Spearman rank correlation ρ₁  (−1 … +1).
        Returns 0.0 if the series is too short or ranks are constant.

    References
    ----------
    Hamed, K. H., & Rao, A. R. (1998). A modified Mann-Kendall trend
        test for autocorrelated data. Journal of Hydrology, 204, 182–196.
        https://doi.org/10.1016/S0022-1694(97)00125-X
    """
    n = len(data)
    if n < 3:
        return 0.0
    ranks = stats.rankdata(data)
    r, _ = stats.spearmanr(ranks[:-1], ranks[1:])
    return float(r) if not np.isnan(r) else 0.0


def _hamed_rao_inflation(data: np.ndarray) -> float:
    """
    Variance inflation factor per Hamed & Rao (1998).

    Lag cap: max_lag = n // 3, so each ACF estimate uses ≥ 3 pairs.
    Significance threshold: only lags with |ρ_k| > 2/√(n−k) are used
    (95 % CI for Spearman correlation), following the same criterion
    applied in the vectorised engine.  This prevents spurious correction
    from noisy lag estimates for short series (n < 20).

    References
    ----------
    Hamed, K. H., & Rao, A. R. (1998). Journal of Hydrology, 204, 182–196.
    """
    n = len(data)
    if n < 4:
        return 1.0

    max_lag = min(n - 4, max(1, n // 3))
    ranks   = stats.rankdata(data)
    inflation = 0.0

    for k in range(1, max_lag + 1):
        if n - k < 2:
            continue
        rho, _ = stats.spearmanr(ranks[:n - k], ranks[k:])
        if np.isnan(rho):
            rho = 0.0
        thresh = 2.0 / np.sqrt(float(n - k))
        if abs(rho) <= thresh:       # not significant — skip this lag
            continue
        weight    = float((n - k) * (n - k - 1) * (n - k - 2))
        inflation += weight * rho

    factor = 1.0 + (2.0 / (n * (n - 1) * (n - 2))) * inflation
    return max(factor, 0.1)


def has_nodata(series: np.ndarray,
               nodata: float = NODATA_VALUE) -> bool:
    """Return True if *series* contains NaN or the NoData sentinel."""
    return bool(np.any(np.isnan(series)) or
                (nodata is not None and np.any(series == nodata)))


# =============================================================================
#  VALIDATION ANALYSIS FUNCTIONS
# =============================================================================

def validate_data_completeness(X: np.ndarray) -> np.ndarray:
    """
    Valid observation count per pixel across the time series.

    Parameters
    ----------
    X : (n, P) array  — full pixel matrix (time × pixels)

    Returns
    -------
    flat (P,) float64 array — number of valid (non-NoData, non-NaN) time steps
    at each pixel (range 0 … n).
    """
    return np.sum((X != NODATA_VALUE) & ~np.isnan(X), axis=0).astype(np.float64)


def detect_outliers_iqr(X: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
    """
    IQR-based outlier count per pixel across the time series.

    A value is flagged as an outlier when it falls outside
    [Q1 − 1.5 × IQR, Q3 + 1.5 × IQR] for that pixel's time series.

    Parameters
    ----------
    X          : (n, P) — full pixel matrix (time × pixels)
    valid_mask : (P,) bool — True for pixels with no NoData in any time step

    Returns
    -------
    flat (P,) float64 array — number of outlier observations per pixel;
    NoData pixels are filled with NODATA_VALUE.
    """
    P = X.shape[1]
    outlier_flat = np.full(P, NODATA_VALUE, dtype=np.float64)
    if not valid_mask.any():
        return outlier_flat
    Xv = X[:, valid_mask]                              # (n, V)
    q1 = np.percentile(Xv, 25, axis=0)                # (V,)
    q3 = np.percentile(Xv, 75, axis=0)                # (V,)
    iqr = q3 - q1
    lo  = q1 - 1.5 * iqr
    hi  = q3 + 1.5 * iqr
    outlier_count = np.sum((Xv < lo[None, :]) | (Xv > hi[None, :]), axis=0)
    outlier_flat[valid_mask] = outlier_count.astype(np.float64)
    return outlier_flat


def bootstrap_trend_consistency(
        pair_slopes_arr: np.ndarray,
        n_bootstrap: int = 100,
        tick_func=None) -> tuple:
    """
    Pairs-bootstrap assessment of Sen's slope reliability.

    Resamples the pre-computed pairwise slopes with replacement (n_bootstrap
    times) and derives two pixel-wise quality metrics:

    * **consistency** – fraction of bootstraps that agree on the sign of the
      slope (range 0.5 – 1.0; 1.0 = all replicates agree perfectly).
    * **ci_width**    – 95 % confidence interval width of the bootstrapped
      slopes (narrower = more precise estimate).

    Parameters
    ----------
    pair_slopes_arr : (num_pairs, V) — pre-computed pairwise slopes for all
        valid pixels (as produced inside run_mast).
    n_bootstrap     : number of bootstrap replicates (default 100).

    Returns
    -------
    consistency : (V,) float64 — sign-agreement fraction (0.5 … 1.0)
    ci_width    : (V,) float64 — 95 % CI width of bootstrapped slopes

    Notes
    -----
    This is a *pairs bootstrap* (resampling slope pairs, not raw time steps).
    It is equivalent to a case bootstrap on the Sen's slope estimator and is
    fully vectorised — no Python per-pixel loop required.
    """
    num_pairs, V = pair_slopes_arr.shape
    # Accumulate bootstrapped medians one replicate at a time.
    # This avoids the (n_bootstrap × num_pairs × V) intermediate array that
    # would require tens of GB of RAM for large rasters.
    # Memory cost per iteration: one (num_pairs, V) fancy-index copy ≈ same as
    # pair_slopes_arr itself, then a (V,) median — manageable for any raster.
    boot_medians = np.empty((n_bootstrap, V), dtype=np.float32)
    for b in range(n_bootstrap):
        idx = np.random.choice(num_pairs, num_pairs, replace=True)
        boot_medians[b] = np.median(pair_slopes_arr[idx], axis=0)
        if tick_func:
            tick_func(b + 1, n_bootstrap)
    # Sign consistency: max(P(slope > 0), P(slope ≤ 0))
    pos_frac    = np.mean(boot_medians > 0, axis=0)      # (V,)
    consistency = np.maximum(pos_frac, 1.0 - pos_frac)   # (V,)
    # 95 % CI width
    ci_width = (np.percentile(boot_medians, 97.5, axis=0) -
                np.percentile(boot_medians, 2.5,  axis=0)).astype(np.float64)
    return consistency.astype(np.float64), ci_width


# =============================================================================
#  ANALYSIS ENGINE
# =============================================================================

def run_mast(arrays: list,
             years: list,
             output_path: str,
             geo_transform,
             projection: str,
             log_func=None,
             apply_autocorr_correction: bool = False,
             run_outlier_detection: bool = True,
             run_bootstrap: bool = False,
             n_bootstrap: int = 100) -> dict:
    """
    Pixel-wise spatio-temporal Mann-Kendall + Sen's slope analysis.

    Parameters
    ----------
    arrays       : list of 2-D np.ndarray
        Raster bands in strict chronological order.
    years        : list of int
        Year label for each array (must match length of *arrays*).
    output_path  : str
        Directory where output GeoTIFFs will be written.
    geo_transform : tuple
        GDAL six-element GeoTransform of the input raster stack.
    projection   : str
        Well-Known Text (WKT) CRS string.
    log_func     : callable | None
        Optional callback for progress messages.

    Returns
    -------
    dict
        Keys: trend_map, p_value_map, slope_map, change_map,
              autocorr_map, statistics.
    """

    def log(msg: str):
        if log_func:
            log_func(msg)
        print(msg)

    rows, cols = arrays[0].shape
    n = len(arrays)

    log(f"\n{'=' * 60}")
    log(f"  {PLUGIN_NAME} {PLUGIN_VERSION} — {PLUGIN_TITLE}")
    log(f"{'=' * 60}")
    log(f"  Grid                     : {rows} rows × {cols} columns")
    log(f"  Time steps               : {years}")
    log(f"  NoData                   : {NODATA_VALUE}")
    if apply_autocorr_correction:
        log(f"  Variance correction      : Hamed & Rao (1998) ✓")
    else:
        log(f"  Variance correction      : None (standard formula)")
    if run_outlier_detection:
        log(f"  Outlier detection        : IQR method ✓")
    if run_bootstrap:
        log(f"  Bootstrap consistency    : n = {n_bootstrap} replicates ✓")

    # ── Build flat pixel matrix  X : shape (n, rows*cols) ───────────────
    total = rows * cols
    X = np.stack([a.ravel().astype(np.float64) for a in arrays], axis=0)
    # X[t, p] = value of time-step t at pixel p

    # ── NoData mask ──────────────────────────────────────────────────────
    nodata_mask  = np.any((X == NODATA_VALUE) | np.isnan(X), axis=0)  # (P,)
    const_mask   = (~nodata_mask) & (np.std(X, axis=0) < 1e-10)
    valid_mask   = (~nodata_mask) & (~const_mask)

    nodata_ct = int(nodata_mask.sum())
    valid     = int(valid_mask.sum())

    # ── Data completeness (valid obs count per pixel — always computed) ──
    completeness_flat = validate_data_completeness(X)   # (P,) 0..n

    log(f"\n  Vectorised NumPy engine  —  {valid:,} valid pixels")

    # ── Initialise output arrays (flat) ──────────────────────────────────
    P = total
    z_flat           = np.full(P, NODATA_VALUE, dtype=np.float64)
    p_flat           = np.full(P, NODATA_VALUE, dtype=np.float64)
    slope_flat       = np.full(P, NODATA_VALUE, dtype=np.float64)
    change_flat      = np.full(P, NODATA_VALUE, dtype=np.float64)
    acf_flat         = np.full(P, NODATA_VALUE, dtype=np.float64)
    outlier_flat     = np.full(P, NODATA_VALUE, dtype=np.float64)
    consistency_flat = np.full(P, NODATA_VALUE, dtype=np.float64)
    ci_width_flat    = np.full(P, NODATA_VALUE, dtype=np.float64)

    # ── Constant pixels → fill zeros ─────────────────────────────────────
    z_flat[const_mask]      = 0.0
    p_flat[const_mask]      = 1.0
    slope_flat[const_mask]  = 0.0
    change_flat[const_mask] = 0.0
    acf_flat[const_mask]    = 0.0

    # ── Work only on valid pixels ─────────────────────────────────────────
    Xv = X[:, valid_mask]   # (n, V)  — V = number of valid pixels

    # ── Total change  (last − first) ─────────────────────────────────────
    change_flat[valid_mask] = Xv[-1] - Xv[0]

    # ─────────────────────────────────────────────────────────────────────
    #  VECTORISED MANN-KENDALL  S statistic
    #  For each concordant pair (i<j): sum sign(x_j - x_i) over all pixels
    # ─────────────────────────────────────────────────────────────────────
    log("  Computing Mann-Kendall S …")
    S = np.zeros(Xv.shape[1], dtype=np.float64)
    for i in range(n - 1):
        for j in range(i + 1, n):
            S += np.sign(Xv[j] - Xv[i])

    var_s0 = n * (n - 1) * (2 * n + 5) / 18.0   # scalar (no-ties formula)

    # ─────────────────────────────────────────────────────────────────────
    #  VECTORISED SPEARMAN RANK ACF  (lag-1 … lag n-1)
    #  Fast argsort-based ranking — O(n log n · V), no Python per-pixel loop
    # ─────────────────────────────────────────────────────────────────────
    log("  Computing Spearman rank autocorrelations …")

    def _fast_rank(M):
        """Rank each column of M (n, V) along the time axis (axis 0)."""
        V_  = M.shape[1]
        order = M.argsort(axis=0)                           # (n, V)
        ranks = np.empty_like(M, dtype=np.float64)
        ranks[order, np.arange(V_)[None, :]] = (
            np.arange(1, M.shape[0] + 1)[:, None])         # broadcast (n,1)
        return ranks

    Rv = _fast_rank(Xv)   # (n, V)  — Spearman ranks for all valid pixels

    def _vec_pearson(A, B):
        """Per-column Pearson correlation between two (k, V) arrays."""
        Am = A - A.mean(axis=0)
        Bm = B - B.mean(axis=0)
        num = (Am * Bm).sum(axis=0)
        den = np.sqrt((Am**2).sum(axis=0) * (Bm**2).sum(axis=0))
        return np.where(den > 1e-12, num / den, 0.0)

    # Lag-1 ACF (always stored, regardless of correction flag)
    lag1_acf_v = _vec_pearson(Rv[:-1], Rv[1:])
    acf_flat[valid_mask] = lag1_acf_v

    # ─────────────────────────────────────────────────────────────────────
    #  HAMED & RAO (1998) VARIANCE CORRECTION  (optional)
    # ─────────────────────────────────────────────────────────────────────
    if apply_autocorr_correction and n >= 4:
        log("  Applying Hamed & Rao (1998) variance correction …")

        # ── Lag cap: for small n, high lags are estimated from very few
        #    pairs and are statistically unreliable.  We follow the common
        #    practice of limiting the correction to lags that have at least
        #    4 observation pairs, i.e. k ≤ n − 4  (minimum), capped further
        #    at n // 3 so that only lags with reasonable power are used.
        #    For n = 9: max_lag = min(5, 3) = 3.
        #    For n ≥ 20: max_lag grows naturally with the series length.
        max_lag = min(n - 4, max(1, n // 3))
        log(f"     Max lag used : {max_lag}  (of {n - 1} possible)")

        # 95 % significance threshold for Spearman lag-k correlation
        # (±2/√(n−k)); lags that don't exceed this threshold are skipped.
        inflation = np.ones(Xv.shape[1], dtype=np.float64)
        used_lags = 0
        for k in range(1, max_lag + 1):
            rho_k  = _vec_pearson(Rv[:n - k], Rv[k:])
            # Per-lag significance threshold
            thresh = 2.0 / np.sqrt(float(n - k))
            # Only apply correction where |ρ_k| exceeds the 95 % threshold
            sig_k  = np.abs(rho_k) > thresh
            if not sig_k.any():
                log(f"     Lag {k}: no pixel exceeds significance threshold "
                    f"(±{thresh:.3f}) — skipped")
                continue
            weight = float((n - k) * (n - k - 1) * (n - k - 2))
            inflation += (2.0 / (n * (n - 1) * (n - 2))) * weight * (
                np.where(sig_k, rho_k, 0.0))
            used_lags += 1

        inflation = np.maximum(inflation, 0.1)
        var_s_v = var_s0 * inflation
        log(f"     Significant lags applied : {used_lags}")
        log(f"     Inflation factor — mean  : {float(np.mean(inflation)):.3f}  "
            f"median : {float(np.median(inflation)):.3f}")
    else:
        var_s_v = np.full(Xv.shape[1], var_s0)

    # ─────────────────────────────────────────────────────────────────────
    #  CONTINUITY-CORRECTED Z STATISTIC  &  TWO-TAILED P-VALUE
    # ─────────────────────────────────────────────────────────────────────
    sqrt_var = np.sqrt(var_s_v)
    Z = np.where(S > 0,  (S - 1.0) / sqrt_var,
        np.where(S < 0,  (S + 1.0) / sqrt_var, 0.0))
    P_val = 2.0 * (1.0 - stats.norm.cdf(np.abs(Z)))

    z_flat[valid_mask] = Z
    p_flat[valid_mask] = P_val

    # ─────────────────────────────────────────────────────────────────────
    #  VECTORISED THEIL-SEN SLOPE
    #  Median of all pairwise slopes (x_j - x_i) / (t_j - t_i)
    # ─────────────────────────────────────────────────────────────────────
    log("  Computing Sen's slope …")
    pair_slopes = []
    for i in range(n - 1):
        for j in range(i + 1, n):
            dt = years[j] - years[i]
            if dt != 0:
                pair_slopes.append((Xv[j] - Xv[i]) / dt)   # (V,)

    pair_slopes_arr = np.stack(pair_slopes, axis=0)           # (num_pairs, V)
    slope_flat[valid_mask] = np.median(pair_slopes_arr, axis=0)

    # ─────────────────────────────────────────────────────────────────────
    #  VALIDATION ANALYSES
    # ─────────────────────────────────────────────────────────────────────

    # Outlier detection (IQR, vectorised)
    if run_outlier_detection:
        log("  Computing IQR outlier counts …")
        outlier_flat = detect_outliers_iqr(X, valid_mask)

    # Bootstrap trend consistency (pairs bootstrap, vectorised)
    if run_bootstrap and pair_slopes_arr.shape[1] > 0:
        log(f"  Computing bootstrap trend consistency  (n = {n_bootstrap}) …")

        def _boot_tick(b: int, total: int):
            if b % 10 == 0 or b == total:
                log(f"     {b}/{total} replicates …")
            QCoreApplication.processEvents()   # keep QGIS UI responsive

        consistency_v, ci_width_v = bootstrap_trend_consistency(
            pair_slopes_arr, n_bootstrap, tick_func=_boot_tick)
        consistency_flat[valid_mask] = consistency_v
        ci_width_flat[valid_mask]    = ci_width_v

    # ─────────────────────────────────────────────────────────────────────
    #  TREND COUNTERS  (α = 0.05)
    # ─────────────────────────────────────────────────────────────────────
    sig_mask = P_val < 0.05
    inc_ct   = int(( sig_mask & (S > 0)).sum())
    dec_ct   = int(( sig_mask & (S < 0)).sum())
    none_ct  = int((~sig_mask).sum()) + int(const_mask.sum())

    # ─────────────────────────────────────────────────────────────────────
    #  RESHAPE FLAT ARRAYS BACK TO (rows, cols)
    # ─────────────────────────────────────────────────────────────────────
    def _reshape(flat):
        return flat.reshape(rows, cols).astype(np.float32)

    trend_map          = _reshape(z_flat)
    p_value_map        = _reshape(p_flat)
    slope_map          = _reshape(slope_flat)
    change_map         = _reshape(change_flat)
    autocorr_map       = _reshape(acf_flat)
    completeness_map   = completeness_flat.reshape(rows, cols).astype(np.float32)
    outlier_map        = _reshape(outlier_flat)
    consistency_map    = _reshape(consistency_flat)
    ci_width_map       = _reshape(ci_width_flat)

    # ── Print summary ─────────────────────────────────────────────────────
    log(f"\n{'=' * 60}")
    log("  ANALYSIS SUMMARY")
    log(f"{'=' * 60}")
    log(f"  Total pixels   : {total:,}")
    log(f"  Valid pixels   : {valid:,}  ({valid / total * 100:.1f} %)")
    log(f"  NoData pixels  : {nodata_ct:,}  ({nodata_ct / total * 100:.1f} %)")
    if valid > 0:
        log(f"\n  Trend direction  (α = 0.05):")
        log(f"    Increasing : {inc_ct:,}  ({inc_ct / valid * 100:.1f} %)")
        log(f"    Decreasing : {dec_ct:,}  ({dec_ct / valid * 100:.1f} %)")
        log(f"    No trend   : {none_ct:,}  ({none_ct / valid * 100:.1f} %)")

    def _stats(label: str, arr: np.ndarray):
        v = arr[(arr != NODATA_VALUE) & ~np.isnan(arr)]
        if len(v):
            log(f"\n  {label}:")
            log(f"    Min    : {np.min(v):.4f}")
            log(f"    Max    : {np.max(v):.4f}")
            log(f"    Mean   : {np.mean(v):.4f}")
            log(f"    Median : {np.median(v):.4f}")
            log(f"    Std    : {np.std(v):.4f}")

    log(f"\n{'=' * 60}")
    log("  OUTPUT RASTER STATISTICS")
    log(f"{'=' * 60}")
    _stats("Trend Map — Z-Score",          trend_map)
    _stats("P-Value",                       p_value_map)
    _stats("Sen's Slope  (units yr⁻¹)",    slope_map)
    _stats("Total Change  (last − first)", change_map)
    _stats("Lag-1 Autocorrelation (ACF)",  autocorr_map)
    _stats("Data Completeness  (obs count)", completeness_map)
    if run_outlier_detection:
        _stats("Outlier Count  (IQR)",     outlier_map)
    if run_bootstrap:
        _stats("Bootstrap Sign Consistency", consistency_map)
        _stats("Sen's Slope 95 % CI Width",  ci_width_map)

    # ── Write GeoTIFFs ────────────────────────────────────────────────────
    log(f"\n  Writing output GeoTIFFs → {output_path}")

    output_files = {
        'trend_map_zscore.tif':   trend_map,
        'p_value.tif':            p_value_map,
        'sens_slope.tif':         slope_map,
        'total_change.tif':       change_map,
        'autocorr_lag1.tif':      autocorr_map,
        'data_completeness.tif':  completeness_map,
    }
    if run_outlier_detection:
        output_files['outlier_count.tif'] = outlier_map
    if run_bootstrap:
        output_files['trend_consistency.tif']  = consistency_map
        output_files['sens_slope_ci_width.tif'] = ci_width_map

    for fname, arr in output_files.items():
        _write_geotiff(arr,
                       os.path.join(output_path, fname),
                       geo_transform, projection, NODATA_VALUE)
        log(f"    ✓ {fname}")

    # ── JSON statistics report ────────────────────────────────────────────
    # Lag-1 ACF summary (valid pixels only)
    _vac = autocorr_map[(autocorr_map != NODATA_VALUE) & ~np.isnan(autocorr_map)]
    acf_summary = ({
        'mean':   float(np.mean(_vac)),
        'median': float(np.median(_vac)),
        'std':    float(np.std(_vac)),
        'pct_positive': float(np.mean(_vac > 0) * 100),
    } if len(_vac) else {})

    stats_dict = {
        'plugin':           PLUGIN_NAME,
        'full_name':        PLUGIN_TITLE,
        'version':          PLUGIN_VERSION,
        'author':           '[ANONYMIZED]',
        'email':            '[ANONYMIZED]',
        'total_pixels':     int(total),
        'valid_pixels':     int(valid),
        'nodata_pixels':    int(nodata_ct),
        'increasing_trend': int(inc_ct),
        'decreasing_trend': int(dec_ct),
        'no_trend':         int(none_ct),
        'years':            years,
        'nodata_value':     NODATA_VALUE,
        'significance_level': 0.05,
        'autocorr_correction': apply_autocorr_correction,
        'lag1_acf_summary': acf_summary,
        'validation': {
            'outlier_detection': run_outlier_detection,
            'bootstrap_consistency': run_bootstrap,
            'n_bootstrap': n_bootstrap if run_bootstrap else None,
        },
        'methods': {
            'trend_test':       'Mann-Kendall (Mann 1945; Kendall 1975)',
            'slope_estimator':  'Theil–Sen (Sen 1968; Theil 1950)',
            'trend_map_unit':   'Z-score (continuous, −∞ to +∞)',
            'variance_correction': (
                'Hamed & Rao (1998) — Spearman rank ACF at all lags'
                if apply_autocorr_correction else 'None'),
            'outlier_method':   'IQR (Q1 − 1.5×IQR, Q3 + 1.5×IQR)' if run_outlier_detection else 'None',
            'consistency_method': f'Pairs bootstrap (n={n_bootstrap})' if run_bootstrap else 'None',
        },
    }

    with open(os.path.join(output_path, 'statistics.json'),
              'w', encoding='utf-8') as f:
        json.dump(stats_dict, f, indent=2, ensure_ascii=False)
    log("    ✓ statistics.json")

    log(f"\n{'=' * 60}")
    log("  MAST ANALYSIS COMPLETED SUCCESSFULLY")
    log(f"{'=' * 60}\n")

    return {
        'trend_map':        trend_map,
        'p_value_map':      p_value_map,
        'slope_map':        slope_map,
        'change_map':       change_map,
        'autocorr_map':     autocorr_map,
        'completeness_map': completeness_map,
        'outlier_map':      outlier_map if run_outlier_detection else None,
        'consistency_map':  consistency_map if run_bootstrap else None,
        'ci_width_map':     ci_width_map if run_bootstrap else None,
        'statistics':       stats_dict,
    }


def _write_geotiff(array: np.ndarray,
                   path: str,
                   geo_transform,
                   projection: str,
                   nodata: float) -> None:
    """Write a single-band float32 GeoTIFF with LZW compression."""
    rows, cols = array.shape
    ds = gdal.GetDriverByName('GTiff').Create(
        path, cols, rows, 1, gdal.GDT_Float32,
        options=['COMPRESS=LZW', 'PREDICTOR=2', 'TILED=YES'])
    ds.SetGeoTransform(geo_transform)
    ds.SetProjection(projection)
    band = ds.GetRasterBand(1)
    band.SetNoDataValue(nodata)
    band.WriteArray(array)
    band.FlushCache()
    ds = None



# =============================================================================
#  DIRECT RENDERER STYLE ENGINE  (uses QGIS API instead of QML)
# =============================================================================

def _valid_pixels(arr: np.ndarray, nodata: float = NODATA_VALUE) -> np.ndarray:
    """Return 1-D array of valid (non-nodata, non-nan) pixels."""
    mask = (arr != nodata) & ~np.isnan(arr)
    return arr[mask].ravel()


def _pct(arr: np.ndarray, p: float) -> float:
    return float(np.percentile(arr, p))



def _apply_renderer(layer, renderer):
    """Applies the renderer and triggers QGIS's full signal chain."""
    layer.setRenderer(renderer)
    layer.setScaleBasedVisibility(False)
    # Update the QGIS legend/layer panel
    if hasattr(layer, 'styleChanged'):
        layer.styleChanged.emit()
    layer.triggerRepaint()


def _make_renderer(layer, color_items, interp=None):
    """
    Builds a QgsSingleBandPseudoColorRenderer from the given colour steps.

    Parameters
    ----------
    layer       : QgsRasterLayer
    color_items : list of (value: float, QColor, label: str)
    interp      : default Discrete — classified legend appearance
    """
    if interp is None:
        interp = QgsColorRampShader.Discrete   # ← always a classified legend

    shader_func = QgsColorRampShader()
    shader_func.setColorRampType(interp)
    shader_func.setClassificationMode(QgsColorRampShader.EqualInterval)

    items = [
        QgsColorRampShader.ColorRampItem(val, color, label)
        for val, color, label in color_items
    ]
    shader_func.setColorRampItemList(items)

    shader = QgsRasterShader()
    shader.setRasterShaderFunction(shader_func)

    return QgsSingleBandPseudoColorRenderer(
        layer.dataProvider(), 1, shader)


def apply_style_zscore(layer, arr):
    """
    Mann-Kendall Z-Score → Discrete classified legend.

    Statistical significance thresholds (±1.28, ±1.96, ±2.58) are used
    as fixed class boundaries when present in the data.
    """
    v = _valid_pixels(arr)
    if not len(v):
        return

    lo = float(np.percentile(v, 1))
    hi = float(np.percentile(v, 99))

    items = []

    # Decreasing side
    if lo < -2.58:
        items.append((-2.58, QColor('#053061'),
                      'Z < −2.58  |  Strong decrease  (α = 0.01)'))
    if lo < -1.96:
        items.append((-1.96, QColor('#2166ac'),
                      '−2.58 … −1.96  |  Significant decrease  (α = 0.05)'))
    if lo < -1.28:
        items.append((-1.28, QColor('#74add1'),
                      '−1.96 … −1.28  |  Weak decrease  (α = 0.20)'))

    items.append((-0.00, QColor('#d1e5f0'),
                  '−1.28 … 0  |  Non-significant decrease'))

    # Increasing side
    items.append((1.28, QColor('#fddbc7'),
                  '0 … +1.28  |  Non-significant increase'))

    if hi > 1.28:
        items.append((1.96, QColor('#f4a582'),
                      '+1.28 … +1.96  |  Weak increase  (α = 0.20)'))
    if hi > 1.96:
        items.append((2.58, QColor('#d6604d'),
                      '+1.96 … +2.58  |  Significant increase  (α = 0.05)'))
    if hi > 2.58:
        items.append((hi,  QColor('#67001f'),
                      f'Z > +2.58  |  Strong increase  (α = 0.01)'))
    else:
        items[-1] = (hi, items[-1][1], items[-1][2])

    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


def apply_style_pvalue(layer, arr):
    """P-value → DISCRETE significance classes (dark purple → white)."""
    v = _valid_pixels(arr)
    if not len(v):
        return

    vmin = float(np.min(v))
    vmax = float(np.max(v))

    all_classes = [
        (0.001, QColor('#40004b'), 'p < 0.001  |  Highly significant'),
        (0.010, QColor('#762a83'), 'p < 0.010  |  Significant  (α = 0.01)'),
        (0.050, QColor('#9970ab'), 'p < 0.050  |  Significant  (α = 0.05)  ★'),
        (0.100, QColor('#f1a340'), 'p < 0.100  |  Marginal  (α = 0.10)'),
        (0.200, QColor('#fee0b6'), 'p < 0.200  |  Not significant'),
        (0.500, QColor('#d9d9d9'), 'p < 0.500  |  Not significant'),
        (1.000, QColor('#f7f7f7'), 'p ≤ 1.000  |  No trend'),
    ]

    items = [cls for cls in all_classes if cls[0] > vmin]
    if not items:
        items = [(1.000, QColor('#f7f7f7'), 'p ≤ 1.000  |  No trend')]

    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


def _apply_style_diverging(layer, arr, neg_label, pos_label,
                            palette_neg, palette_pos):
    """
    General diverging classified style — 10 Discrete classes.
    Symmetric axis derived from p2/p98 percentiles of valid pixels.
    """
    v = _valid_pixels(arr)
    if not len(v):
        return

    half = max(abs(_pct(v, 2)), abs(_pct(v, 98)))
    if half < 1e-12:
        half = 1.0
    lo, hi = -half, half

    b0, b1, b2, b3, b4 = lo, lo*0.60, lo*0.30, lo*0.10, 0.0
    c0, c1, c2, c3, c4 = hi*0.10, hi*0.30, hi*0.60, hi*0.90, hi

    items = [
        (b1, QColor(palette_neg[0]),
             f'{b0:.4g} … {b1:.4g}  |  {neg_label}  (very strong)'),
        (b2, QColor(palette_neg[1]),
             f'{b1:.4g} … {b2:.4g}  |  {neg_label}  (strong)'),
        (b3, QColor(palette_neg[2]),
             f'{b2:.4g} … {b3:.4g}  |  {neg_label}  (moderate)'),
        (b4, QColor(palette_neg[3]),
             f'{b3:.4g} … 0  |  {neg_label}  (slight)'),
        (c0, QColor('#f7f7f7'),
             '≈ 0  |  No change'),
        (c1, QColor(palette_pos[0]),
             f'{c0:.4g} … {c1:.4g}  |  {pos_label}  (slight)'),
        (c2, QColor(palette_pos[1]),
             f'{c1:.4g} … {c2:.4g}  |  {pos_label}  (moderate)'),
        (c3, QColor(palette_pos[2]),
             f'{c2:.4g} … {c3:.4g}  |  {pos_label}  (strong)'),
        (c4, QColor(palette_pos[3]),
             f'{c3:.4g} … {c4:.4g}  |  {pos_label}  (very strong)'),
        (c4, QColor(palette_pos[4]),
             f'> {c3:.4g}  |  {pos_label}  (maximum)'),
    ]

    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


def apply_style_slope(layer, arr):
    """Sen's Slope → brown (decrease) ↔ white ↔ green (increase)."""
    _apply_style_diverging(
        layer, arr, 'Decrease', 'Increase',
        ['#543005', '#8c510a', '#bf812d', '#dfc27d', '#f6e8c3'],
        ['#c7eae5', '#80cdc1', '#35978f', '#01665e', '#003c30'],
    )


def apply_style_change(layer, arr):
    """Total Change → purple (loss) ↔ white ↔ green (gain)."""
    _apply_style_diverging(
        layer, arr, 'Loss', 'Gain',
        ['#40004b', '#762a83', '#af8dc3', '#c2a5cf', '#e7d4e8'],
        ['#d9f0d3', '#a6dba0', '#5aae61', '#1b7837', '#00441b'],
    )


def apply_style_autocorr(layer, arr):
    """
    Lag-1 ACF → 7-class DISCRETE scheme.

    Strong negative (blue) ↔ uncorrelated (white) ↔ strong positive (red).
    Class boundaries at ρ₁ = ±0.10, ±0.30, ±0.50 and ±1.00.
    """
    v = _valid_pixels(arr)
    if not len(v):
        return

    items = [
        (-0.50, QColor('#053061'), 'ρ₁ < −0.50  |  Strong negative ACF'),
        (-0.30, QColor('#2166ac'), '−0.50 … −0.30  |  Moderate negative ACF'),
        (-0.10, QColor('#92c5de'), '−0.30 … −0.10  |  Weak negative ACF'),
        ( 0.10, QColor('#f7f7f7'), '−0.10 … +0.10  |  Uncorrelated'),
        ( 0.30, QColor('#f4a582'), '+0.10 … +0.30  |  Weak positive ACF'),
        ( 0.50, QColor('#d6604d'), '+0.30 … +0.50  |  Moderate positive ACF'),
        ( 1.00, QColor('#67001f'), 'ρ₁ > +0.50  |  Strong positive ACF'),
    ]

    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


def apply_style_completeness(layer, arr, n_timesteps: int):
    """
    Data completeness → discrete classes from 0 to n_timesteps.

    Red (no data) → yellow (partial) → green (full coverage).
    """
    v = _valid_pixels(arr)
    if not len(v):
        return
    items = []
    if n_timesteps > 0:
        thresholds = [
            (0,                     QColor('#d73027'), 'No valid obs  (0)'),
            (n_timesteps * 0.25,    QColor('#f46d43'), f'< 25 %  (≤ {int(n_timesteps*0.25)})'),
            (n_timesteps * 0.50,    QColor('#fdae61'), f'25 – 50 %  (≤ {int(n_timesteps*0.50)})'),
            (n_timesteps * 0.75,    QColor('#fee08b'), f'50 – 75 %  (≤ {int(n_timesteps*0.75)})'),
            (n_timesteps * 0.99,    QColor('#a6d96a'), f'75 – 99 %'),
            (float(n_timesteps),    QColor('#1a9641'), f'Full coverage  ({n_timesteps})'),
        ]
        items = [(v, c, l) for v, c, l in thresholds]
    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


def apply_style_outliers(layer, arr):
    """
    IQR outlier count → 5-class discrete scheme.

    White (0 outliers) → orange → red (many outliers).
    """
    v = _valid_pixels(arr)
    if not len(v):
        return
    max_val = max(1, int(np.max(v)))
    items = [
        (0,                      QColor('#f7f7f7'), '0 outliers  |  Clean'),
        (1,                      QColor('#fee08b'), '1 outlier'),
        (2,                      QColor('#fc8d59'), '2 outliers'),
        (3,                      QColor('#d73027'), '3 outliers'),
        (float(max_val),         QColor('#67001f'), f'≥ 4 outliers  (max {max_val})'),
    ]
    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


def apply_style_consistency(layer, arr):
    """
    Bootstrap sign consistency → 5-class discrete scheme.

    Grey (0.5 = uncertain) → green (1.0 = fully consistent).
    """
    v = _valid_pixels(arr)
    if not len(v):
        return
    items = [
        (0.60, QColor('#d9d9d9'), '≤ 0.60  |  Very uncertain'),
        (0.70, QColor('#fee08b'), '0.60 – 0.70  |  Uncertain'),
        (0.80, QColor('#a6d96a'), '0.70 – 0.80  |  Moderate'),
        (0.90, QColor('#4dac26'), '0.80 – 0.90  |  Reliable'),
        (1.00, QColor('#1a6314'), '0.90 – 1.00  |  Highly consistent'),
    ]
    _apply_renderer(layer, _make_renderer(layer, items, QgsColorRampShader.Discrete))


class MASTDialog(QDialog):
    """Primary user interface for the MAST plugin."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(
            f"{PLUGIN_NAME} {PLUGIN_VERSION} — {PLUGIN_TITLE}")
        self.setMinimumWidth(960)
        self.setMinimumHeight(740)

        if not SCIPY_AVAILABLE:
            QMessageBox.critical(
                self, "Missing Dependencies",
                "MAST requires the following Python packages:\n"
                "  • scipy\n  • matplotlib\n\n"
                "Install them via the OSGeo4W Shell:\n"
                "  python -m pip install scipy matplotlib\n\n"
                "Then restart QGIS.")
            return

        self.selected_rasters: list      = []
        self.output_path:       str      = ""
        self.results:           dict|None = None

        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout()

        # ── Section 1: Raster input ───────────────────────────────────────
        grp1 = QGroupBox("1 · Time Series Raster Layers")
        lay1 = QVBoxLayout()

        info = QLabel(
            f"Select rasters representing the same geophysical parameter "
            f"at successive points in time.\n"
            f"Example: NDVI_2000, NDVI_2005, …, NDVI_2024\n"
            f"All layers must share identical CRS, spatial extent and "
            f"grid dimensions.   NoData sentinel: {NODATA_VALUE}\n"
            f"Trend output: Mann-Kendall Z-score (continuous, −∞ to +∞)  "
            f"|  Slope output: Sen's slope (units yr⁻¹)"
        )
        info.setWordWrap(True)
        info.setStyleSheet(
            "color:#1a237e; padding:8px; "
            "background:#e8eaf6; border-radius:4px;")
        lay1.addWidget(info)

        row = QHBoxLayout()

        # Left — project rasters + file/folder buttons
        left = QVBoxLayout()
        left.addWidget(QLabel("Available Project Rasters:"))
        self.avail_list = QListWidget()
        self.avail_list.setSelectionMode(
            QListWidget.SelectionMode.MultiSelection)
        self._load_project_rasters()
        left.addWidget(self.avail_list)

        # Reload + file-based loading buttons
        file_row = QHBoxLayout()
        reload_btn = QPushButton("🔄  Refresh")
        reload_btn.setToolTip("Refresh the layer list from the current QGIS project")
        reload_btn.clicked.connect(self._load_project_rasters)
        file_row.addWidget(reload_btn)

        add_files_btn = QPushButton("📂  Select File(s)…")
        add_files_btn.setToolTip(
            "Select one or more raster files from disk (.tif, .tiff, .img, etc.)")
        add_files_btn.clicked.connect(self._add_from_files)
        file_row.addWidget(add_files_btn)

        add_folder_btn = QPushButton("🗂  Add from Folder…")
        add_folder_btn.setToolTip(
            "Automatically scan and add all raster files within a selected folder")
        add_folder_btn.clicked.connect(self._add_from_folder)
        file_row.addWidget(add_folder_btn)
        left.addLayout(file_row)

        # Centre — transfer buttons
        mid = QVBoxLayout()
        mid.addStretch()
        for label, slot in [
            ("→  Add",    self._add_rasters),
            ("←  Remove", self._remove_rasters),
            ("✕  Clear",  self._clear_selection),
        ]:
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            mid.addWidget(btn)
        mid.addStretch()

        # Right — selected table
        right = QVBoxLayout()
        right.addWidget(QLabel("Selected Time Series  (Layer | Year):"))
        self.sel_table = QTableWidget()
        self.sel_table.setColumnCount(2)
        self.sel_table.setHorizontalHeaderLabels(["Raster Layer", "Year"])
        self.sel_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch)
        self.sel_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.ResizeToContents)
        self.sel_table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        right.addWidget(self.sel_table)

        row.addLayout(left, 1)
        row.addLayout(mid,  0)
        row.addLayout(right, 1)
        lay1.addLayout(row)
        grp1.setLayout(lay1)
        root.addWidget(grp1)

        # ── Section 2: Output settings ────────────────────────────────────
        grp2 = QGroupBox("2 · Output Settings")
        lay2 = QVBoxLayout()

        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("Output Directory:"))
        self.out_label = QLabel("— not selected —")
        self.out_label.setStyleSheet(
            "border:1px solid #bbb; padding:5px; background:white;")
        path_row.addWidget(self.out_label, 1)
        browse = QPushButton("📁  Browse …")
        browse.clicked.connect(self._browse_output)
        path_row.addWidget(browse)
        lay2.addLayout(path_row)

        opt_row = QHBoxLayout()
        self.chk_load = QCheckBox("Load output layers into QGIS")
        self.chk_load.setChecked(True)
        self.chk_viz  = QCheckBox("Open visualisation after analysis")
        self.chk_viz.setChecked(True)
        opt_row.addWidget(self.chk_load)
        opt_row.addWidget(self.chk_viz)
        opt_row.addStretch()
        lay2.addLayout(opt_row)

        # ── Autocorrelation correction option ─────────────────────────────
        acf_row = QHBoxLayout()
        self.chk_autocorr = QCheckBox(
            "Apply autocorrelation correction  (Hamed & Rao, 1998)")
        self.chk_autocorr.setChecked(False)
        self.chk_autocorr.setToolTip(
            "Applies the Hamed & Rao (1998) variance correction to the "
            "Mann-Kendall test.\n\n"
            "WHAT IT DOES:\n"
            "When time series observations are positively autocorrelated, "
            "the standard MK variance formula underestimates Var(S),\n"
            "inflating Z-scores and increasing the risk of false positives "
            "(Type I error).\n\n"
            "HOW IT WORKS:\n"
            "Multiplies Var(S) by an inflation factor derived from lag-k "
            "Spearman rank correlations — but ONLY for:\n"
            "  • Lags up to min(n−4, n//3) [avoids unreliable high lags "
            "estimated from very few pairs]\n"
            "  • Lags where |ρ_k| > 2/√(n−k) [95% significance threshold; "
            "insignificant autocorrelations are ignored]\n\n"
            "IMPORTANT FOR SMALL n:\n"
            "With n = 9 (five-year composites), the lag-1 significance "
            "threshold is ±2/√8 ≈ ±0.71.\n"
            "If the observed lag-1 ACF is below this threshold (common for "
            "well-separated composites),\n"
            "no correction is applied and results are identical to the "
            "standard MK test.\n\n"
            "ALSO PRODUCES: autocorr_lag1.tif — pixel-wise lag-1 Spearman "
            "ACF map (−1 to +1), always written regardless of this setting.\n\n"
            "REFERENCE: Hamed & Rao (1998), J. Hydrology, 204, 182–196.\n"
            "https://doi.org/10.1016/S0022-1694(97)00125-X")
        self.chk_autocorr.setStyleSheet(
            "color:#6a1010; font-style: italic;")
        acf_row.addWidget(self.chk_autocorr)
        acf_row.addStretch()
        lay2.addLayout(acf_row)

        # ── Validation options ────────────────────────────────────────────
        val_row = QHBoxLayout()
        self.chk_outliers = QCheckBox("Detect outliers  (IQR method)")
        self.chk_outliers.setChecked(True)
        self.chk_outliers.setToolTip(
            "Counts IQR-based outliers per pixel across the time series.\n\n"
            "A value is flagged when it falls outside:\n"
            "  Q1 − 1.5 × IQR  …  Q3 + 1.5 × IQR\n\n"
            "Output: outlier_count.tif  (0 … n, integer)\n"
            "Use this layer to identify pixels with unreliable time series.")
        val_row.addWidget(self.chk_outliers)

        self.chk_bootstrap = QCheckBox(
            "Bootstrap trend consistency  (n = 100)")
        self.chk_bootstrap.setChecked(False)
        self.chk_bootstrap.setToolTip(
            "Assesses the reliability of each pixel's Sen's slope via a\n"
            "pairs bootstrap (100 replicates, fully vectorised).\n\n"
            "Outputs:\n"
            "  trend_consistency.tif   — sign-agreement fraction (0.5 – 1.0)\n"
            "    1.0 = all replicates agree on slope direction\n"
            "    0.5 = direction is completely uncertain\n"
            "  sens_slope_ci_width.tif — 95 % CI width of slope estimate\n\n"
            "Recommended for publication-quality uncertainty mapping.\n"
            "Adds ~5 – 10 s on large rasters (vectorised, no per-pixel loop).")
        self.chk_bootstrap.setStyleSheet("color:#1a4d8f; font-style:italic;")
        val_row.addWidget(self.chk_bootstrap)
        val_row.addStretch()
        lay2.addLayout(val_row)

        grp2.setLayout(lay2)
        root.addWidget(grp2)

        # ── Section 3: Actions ────────────────────────────────────────────
        act_row = QHBoxLayout()

        self.run_btn = QPushButton("▶  Run MAST Analysis")
        self.run_btn.setStyleSheet(
            "background:#2e7d32; color:white; font-weight:bold; "
            "padding:10px; border-radius:4px;")
        self.run_btn.clicked.connect(self._run)
        act_row.addWidget(self.run_btn)

        self.viz_btn = QPushButton("📊  Open Visualisation")
        self.viz_btn.setEnabled(False)
        self.viz_btn.clicked.connect(self._show_viz)
        act_row.addWidget(self.viz_btn)

        root.addLayout(act_row)

        self.progress = QProgressBar()
        root.addWidget(self.progress)

        # ── Section 4: Log ────────────────────────────────────────────────
        grp4 = QGroupBox("4 · Analysis Log")
        lay4 = QVBoxLayout()
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(210)
        self.log_box.setFontFamily("Courier New")
        lay4.addWidget(self.log_box)
        grp4.setLayout(lay4)
        root.addWidget(grp4)

        self.setLayout(root)

    # ── Helpers ───────────────────────────────────────────────────────────

    def _load_project_rasters(self):
        self.avail_list.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsRasterLayer):
                self.avail_list.addItem(layer.name())

    # ── File / Folder loading ─────────────────────────────────────────

    @staticmethod
    def _raster_extensions():
        return (
            '.tif', '.tiff', '.img', '.vrt',
            '.adf', '.nc',  '.hdf', '.h5',
            '.jp2', '.ecw', '.ers', '.asc',
        )

    def _add_from_files(self):
        """Allows the user to select individual raster files from disk."""
        paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Select Raster Files",
            "",
            "Raster files (*.tif *.tiff *.img *.vrt *.nc *.hdf *.h5 "
            "*.jp2 *.ecw *.ers *.asc);;All files (*.*)")
        if not paths:
            return

        added = 0
        for path in paths:
            name = os.path.basename(path)
            # Skip if already in the list
            if any(r.get('path') == path for r in self.selected_rasters):
                continue
            # Year estimate: 4-digit number in file name
            import re
            matches = re.findall(r'\b(1[89]\d{2}|20\d{2})\b', name)
            guess   = int(matches[0]) if matches else 2000

            year, ok = QInputDialog.getInt(
                self, "Assign Year",
                f"Year for «{name}»:", guess, 1900, 2100)
            if not ok:
                continue

            # Temporary QgsRasterLayer object (outside QGIS project)
            layer = QgsRasterLayer(path, name)
            if not layer.isValid():
                QMessageBox.warning(
                    self, "Invalid File",
                    f"The following file could not be opened:\n{path}")
                continue

            self.selected_rasters.append(
                {'name': name, 'path': path, 'layer': layer, 'year': year})
            added += 1

        if added:
            self._refresh_table()
            self._log(f"  {added} file(s) added to the list (from disk).")

    def _add_from_folder(self):
        """Scans all raster files in a folder and adds them to the list."""
        folder = QFileDialog.getExistingDirectory(
            self, "Select Raster Folder")
        if not folder:
            return

        ext = self._raster_extensions()
        candidates = sorted([
            f for f in os.listdir(folder)
            if os.path.splitext(f)[1].lower() in ext
        ])

        if not candidates:
            QMessageBox.information(
                self, "No Files Found",
                f"No supported raster files were found in the selected folder.\n"
                f"({folder})")
            return

        import re
        added = 0
        for fname in candidates:
            path = os.path.join(folder, fname)
            if any(r.get('path') == path for r in self.selected_rasters):
                continue

            # Year estimate: 4-digit number in file name
            matches = re.findall(r'\b(1[89]\d{2}|20\d{2})\b', fname)
            guess   = int(matches[0]) if matches else 2000

            year, ok = QInputDialog.getInt(
                self, "Assign Year",
                f"Year for «{fname}»:", guess, 1900, 2100)
            if not ok:
                continue

            layer = QgsRasterLayer(path, fname)
            if not layer.isValid():
                QMessageBox.warning(
                    self, "Invalid File",
                    f"Could not open file:\n{path}")
                continue

            self.selected_rasters.append(
                {'name': fname, 'path': path, 'layer': layer, 'year': year})
            added += 1

        if added:
            self._refresh_table()
            self._log(f"  {added} file(s) added from folder: {folder}")

    def _add_rasters(self):
        for item in self.avail_list.selectedItems():
            name = item.text()
            if any(r['name'] == name and 'path' not in r
                   for r in self.selected_rasters):
                continue
            year, ok = QInputDialog.getInt(
                self, "Assign Year",
                f"Year for  «{name}»:", 2000, 1900, 2100)
            if ok:
                layer = QgsProject.instance().mapLayersByName(name)[0]
                self.selected_rasters.append(
                    {'name': name, 'layer': layer, 'year': year})
                self._refresh_table()

    def _remove_rasters(self):
        rows = {idx.row()
                for idx in self.sel_table.selectedIndexes()}
        for r in sorted(rows, reverse=True):
            del self.selected_rasters[r]
        self._refresh_table()

    def _clear_selection(self):
        self.selected_rasters = []
        self._refresh_table()

    def _refresh_table(self):
        self.sel_table.setRowCount(0)
        for r in sorted(self.selected_rasters, key=lambda x: x['year']):
            row = self.sel_table.rowCount()
            self.sel_table.insertRow(row)
            self.sel_table.setItem(row, 0, QTableWidgetItem(r['name']))
            self.sel_table.setItem(row, 1, QTableWidgetItem(str(r['year'])))

    def _browse_output(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select Output Directory")
        if folder:
            self.output_path = folder
            self.out_label.setText(folder)

    def _log(self, msg: str):
        self.log_box.append(msg)
        QCoreApplication.processEvents()

    # ── Analysis ──────────────────────────────────────────────────────────

    def _run(self):
        if len(self.selected_rasters) < 3:
            QMessageBox.warning(
                self, "Insufficient Input",
                "Please select at least 3 raster layers.\n"
                "A minimum of 3 time steps is required for a "
                "meaningful Mann-Kendall test.")
            return

        if not self.output_path:
            QMessageBox.warning(
                self, "No Output Directory",
                "Please select an output directory before running.")
            return

        self.run_btn.setEnabled(False)
        self.progress.setValue(0)
        self.log_box.clear()

        try:
            self._log("=" * 60)
            self._log(f"  {PLUGIN_NAME} {PLUGIN_VERSION}")
            self._log(f"  {PLUGIN_TITLE}")
            self._log(f"  Author : [ANONYMIZED FOR PEER REVIEW]")
            self._log("=" * 60)

            sorted_rs = sorted(self.selected_rasters, key=lambda x: x['year'])
            years = [r['year'] for r in sorted_rs]

            self._log(f"\n  Time range  : {years[0]} – {years[-1]}"
                      f"  ({len(years)} time steps)")
            self._log(f"  Output path : {self.output_path}")

            # ── Read rasters ──────────────────────────────────────────
            self._log("\n  Reading raster datasets …")
            arrays, geo_transform, projection = [], None, None

            for idx, r in enumerate(sorted_rs):
                ds = gdal.Open(r['layer'].dataProvider().dataSourceUri())
                if ds is None:
                    raise RuntimeError(
                        f"Cannot open raster: {r['name']}")

                if idx == 0:
                    geo_transform = ds.GetGeoTransform()
                    projection    = ds.GetProjection()
                    srs = osr.SpatialReference()
                    srs.ImportFromWkt(projection)
                    epsg = srs.GetAuthorityCode(None)
                    self._log(f"  CRS : "
                              f"{'EPSG:' + epsg if epsg else projection[:60] + '…'}")

                band  = ds.GetRasterBand(1)
                array = band.ReadAsArray().astype(np.float64)

                # Harmonise foreign NoData values
                nd = band.GetNoDataValue()
                if nd is not None and nd != NODATA_VALUE:
                    self._log(
                        f"    ⚠ {r['name']}: NoData {nd} → "
                        f"remapped to {NODATA_VALUE}")
                    array[array == nd] = NODATA_VALUE

                arrays.append(array)
                self._log(f"    ✓ {r['year']}  {r['name']}")
                self.progress.setValue(
                    int(30 * (idx + 1) / len(sorted_rs)))
                ds = None

            if not projection or geo_transform is None:
                raise RuntimeError(
                    "No CRS information found. "
                    "Assign a coordinate reference system to all "
                    "input rasters before running MAST.")

            # ── Run MAST ──────────────────────────────────────────────
            self._log("\n  Executing MAST analysis …")
            if self.chk_autocorr.isChecked():
                self._log(
                    "  ⚠  Hamed & Rao (1998) variance correction ENABLED\n"
                    "     (increases computation time by ~n fold per pixel)")
            self.progress.setValue(40)

            report = run_mast(arrays, years, self.output_path,
                              geo_transform, projection, self._log,
                              apply_autocorr_correction=self.chk_autocorr.isChecked(),
                              run_outlier_detection=self.chk_outliers.isChecked(),
                              run_bootstrap=self.chk_bootstrap.isChecked(),
                              n_bootstrap=100)
            self.progress.setValue(80)

            # ── Load into QGIS ────────────────────────────────────────
            if self.chk_load.isChecked():
                self._log("\n  Loading output layers into QGIS …")

                _n = len(years)
                style_map = {
                    'trend_map_zscore.tif': (
                        'Trend Map — Z-Score (MAST)',
                        lambda lyr: apply_style_zscore(lyr, report['trend_map'])),
                    'p_value.tif': (
                        'P-Value (MAST)',
                        lambda lyr: apply_style_pvalue(lyr, report['p_value_map'])),
                    'sens_slope.tif': (
                        "Sen's Slope (MAST)",
                        lambda lyr: apply_style_slope(lyr, report['slope_map'])),
                    'total_change.tif': (
                        'Total Change (MAST)',
                        lambda lyr: apply_style_change(lyr, report['change_map'])),
                    'autocorr_lag1.tif': (
                        'Lag-1 Autocorrelation — ACF (MAST)',
                        lambda lyr: apply_style_autocorr(lyr, report['autocorr_map'])),
                    'data_completeness.tif': (
                        'Data Completeness (MAST)',
                        lambda lyr, _n=_n: apply_style_completeness(
                            lyr, report['completeness_map'], _n)),
                    'outlier_count.tif': (
                        'Outlier Count — IQR (MAST)',
                        lambda lyr: apply_style_outliers(lyr, report['outlier_map'])),
                    'trend_consistency.tif': (
                        'Bootstrap Trend Consistency (MAST)',
                        lambda lyr: apply_style_consistency(
                            lyr, report['consistency_map'])),
                    'sens_slope_ci_width.tif': (
                        "Sen's Slope 95% CI Width (MAST)",
                        lambda lyr: apply_style_slope(lyr, report['ci_width_map'])),
                }

                for fname, (lyr_name, style_fn) in style_map.items():
                    fpath = os.path.join(self.output_path, fname)
                    if not os.path.exists(fpath):
                        continue
                    layer = QgsRasterLayer(fpath, lyr_name)
                    if not layer.isValid():
                        self._log(f"    ✗ {lyr_name}  [invalid layer]")
                        continue
                    # addMapLayer returns the registered layer reference
                    # — the style must be applied to this, not the original object
                    registered = QgsProject.instance().addMapLayer(layer)
                    try:
                        style_fn(registered)
                        self._log(f"    ✓ {lyr_name}  [✓ style]")
                    except Exception as e:
                        self._log(f"    ✓ {lyr_name}  [style error: {e}]")

            # ── Cache for visualisation ───────────────────────────────
            self.results = {
                'arrays':           arrays,
                'years':            years,
                'trend_map':        report['trend_map'],
                'p_value_map':      report['p_value_map'],
                'slope_map':        report['slope_map'],
                'change_map':       report['change_map'],
                'autocorr_map':     report['autocorr_map'],
                'completeness_map': report['completeness_map'],
                'outlier_map':      report['outlier_map'],
                'consistency_map':  report['consistency_map'],
                'ci_width_map':     report['ci_width_map'],
                'statistics':       report['statistics'],
                'nodata_value':     NODATA_VALUE,
                'autocorr_correction': self.chk_autocorr.isChecked(),
            }

            self.progress.setValue(100)
            self.viz_btn.setEnabled(True)

            acf_note = (
                "\n  • autocorr_lag1.tif       — lag-1 Spearman ACF (−1 to +1)"
                + ("\n  ★ Hamed & Rao (1998) variance correction applied"
                   if self.chk_autocorr.isChecked() else
                   "\n  ℹ Standard variance formula (no ACF correction)")
            )
            val_note = "\n  • data_completeness.tif   — valid obs count per pixel"
            if self.chk_outliers.isChecked():
                val_note += "\n  • outlier_count.tif       — IQR outlier count per pixel"
            if self.chk_bootstrap.isChecked():
                val_note += ("\n  • trend_consistency.tif   — bootstrap sign consistency (0.5–1.0)"
                             "\n  • sens_slope_ci_width.tif — 95 % CI width of slope")

            QMessageBox.information(
                self, "MAST — Analysis Complete",
                f"{PLUGIN_NAME} {PLUGIN_VERSION} finished successfully.\n\n"
                "Output files:\n"
                "  • trend_map_zscore.tif    — Z-score (−∞ to +∞)\n"
                "  • p_value.tif             — significance map (0–1)\n"
                "  • sens_slope.tif          — rate of change (units yr⁻¹)\n"
                "  • total_change.tif        — first to last observation\n"
                f"{acf_note}\n"
                f"{val_note}\n"
                "  • statistics.json         — full summary report\n\n"
                f"Output directory:\n{self.output_path}")

            if self.chk_viz.isChecked():
                self._show_viz()

        except Exception as exc:
            self._log(f"\n  ERROR: {exc}")
            self._log(traceback.format_exc())
            QMessageBox.critical(
                self, "MAST — Analysis Error",
                f"An error occurred:\n\n{exc}")
        finally:
            self.run_btn.setEnabled(True)

    def _show_viz(self):
        if self.results:
            dlg = MASTVisualisationDialog(
                self.results, self.output_path, self)
            dlg.exec()


# =============================================================================
#  VISUALISATION DIALOG
# =============================================================================

class MASTVisualisationDialog(QDialog):
    """Four-panel statistical visualisation dashboard for MAST results."""

    def __init__(self, results: dict, output_path: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle(
            f"{PLUGIN_NAME} {PLUGIN_VERSION} — Statistical Visualisation")
        self.setMinimumWidth(1480)
        self.setMinimumHeight(860)

        self.results      = results
        self.output_path  = output_path
        self.nodata_value = results.get('nodata_value', NODATA_VALUE)

        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()

        self.figure, self.axes = plt.subplots(2, 3, figsize=(18, 10))
        self.canvas = FigureCanvasQTAgg(self.figure)
        layout.addWidget(self.canvas)

        # ── Button row ────────────────────────────────────────────────────
        btn_row = QHBoxLayout()

        refresh_btn = QPushButton("⟳  Refresh Charts")
        refresh_btn.clicked.connect(self._plot)
        btn_row.addWidget(refresh_btn)

        btn_row.addStretch()

        # Format selector
        fmt_label = QLabel("Save format:")
        btn_row.addWidget(fmt_label)

        self.fmt_combo = QComboBox()
        self.fmt_combo.addItems(["PNG (300 DPI)", "PNG (600 DPI)", "JPG (300 DPI)", "JPG (600 DPI)"])
        self.fmt_combo.setFixedWidth(160)
        btn_row.addWidget(self.fmt_combo)

        save_btn = QPushButton("💾  Save Charts")
        save_btn.setStyleSheet(
            "background:#0277bd; color:white; font-weight:bold; "
            "padding:8px 14px; border-radius:4px;")
        save_btn.setToolTip(
            "Saves charts to the output folder at publication quality.\n"
            "Each panel as a separate file + all panels combined in one file.")
        save_btn.clicked.connect(self._save_figures)
        btn_row.addWidget(save_btn)

        layout.addLayout(btn_row)
        self.setLayout(layout)
        self._plot()

    def _mask(self, arr: np.ndarray) -> np.ma.MaskedArray:
        return np.ma.array(
            arr, mask=(arr == self.nodata_value) | np.isnan(arr))

    def _valid(self, arr: np.ndarray) -> np.ndarray:
        return arr[(arr != self.nodata_value) & ~np.isnan(arr)]

    def _plot(self):
        for ax in self.axes.flat:
            ax.clear()

        years  = self.results['years']
        arrays = self.results['arrays']
        st     = self.results['statistics']

        # ── Publication-quality style settings ───────────────────────────
        for ax in self.axes.flat:
            ax.tick_params(labelsize=10)
            for spine in ax.spines.values():
                spine.set_linewidth(0.8)
                spine.set_color('#333333')

        # ── Panel 1: Regional mean time series ───────────────────────────
        ax1    = self.axes[0, 0]
        means  = [float(np.ma.mean(self._mask(a))) for a in arrays]

        ax1.plot(years, means, 'o-', lw=2.5, ms=7,
                 color='#1565c0', label='Regional mean',
                 markerfacecolor='white', markeredgewidth=2.0)

        from scipy import stats as sp
        slope_ols, intercept, r, *_ = sp.linregress(years, means)
        ax1.plot(years,
                 [slope_ols * y + intercept for y in years],
                 '--', color='#c62828', lw=1.8,
                 label=f'OLS: {slope_ols:+.4f} yr⁻¹  '
                       f'(R² = {r**2:.3f})')

        ax1.set_xlabel('Year', fontsize=11, fontweight='bold')
        ax1.set_ylabel('Mean Value', fontsize=11, fontweight='bold')
        ax1.set_title('Regional Mean Time Series', fontsize=13,
                      fontweight='bold', pad=10)
        ax1.legend(fontsize=9, framealpha=0.9, edgecolor='#cccccc')
        ax1.grid(True, alpha=0.3, linewidth=0.6)

        # ── Panel 2: Trend direction pie chart ───────────────────────────
        ax2 = self.axes[0, 1]
        raw = [
            (st['increasing_trend'], 'Increasing', '#2e7d32', 0.06),
            (st['decreasing_trend'], 'Decreasing', '#c62828', 0.06),
            (st['no_trend'],         'No Trend',   '#757575', 0.00),
        ]
        filtered = [(s, l, c, e) for s, l, c, e in raw if s > 0]
        if filtered:
            sizes, labels, colors, explode = zip(*filtered)
            wedges, texts, autotexts = ax2.pie(
                sizes, explode=explode, labels=labels, colors=colors,
                autopct='%1.1f %%', shadow=False, startangle=90,
                textprops={'fontsize': 10},
                wedgeprops={'linewidth': 0.8, 'edgecolor': 'white'})
            for at in autotexts:
                at.set_fontsize(9)
                at.set_fontweight('bold')
        ax2.set_title('Trend Direction Distribution  (α = 0.05)',
                      fontsize=13, fontweight='bold', pad=10)

        # ── Panel 3: Z-score histogram ────────────────────────────────────
        ax3  = self.axes[1, 0]
        vz   = self._valid(self.results['trend_map'])

        if len(vz):
            ax3.hist(vz, bins=100, color='#1565c0',
                     edgecolor='none', alpha=0.80, linewidth=0.4)
            ax3.axvline(0,     color='#c62828', ls='--', lw=2.0,
                        label='No trend  (Z = 0)')
            ax3.axvline(-1.96, color='#e65100', ls=':',  lw=1.5,
                        label='α = 0.05  (Z = ±1.96)')
            ax3.axvline( 1.96, color='#e65100', ls=':',  lw=1.5)
            ax3.axvline(float(np.median(vz)), color='#00695c',
                        ls='--', lw=2.0,
                        label=f'Median Z = {np.median(vz):.3f}')
            ax3.legend(fontsize=8, framealpha=0.9, edgecolor='#cccccc')
            ax3.text(0.02, 0.97,
                     f"n = {len(vz):,}\n"
                     f"Min  = {np.min(vz):.2f}\n"
                     f"Max  = {np.max(vz):.2f}\n"
                     f"Mean = {np.mean(vz):.3f}\n"
                     f"Std  = {np.std(vz):.3f}",
                     transform=ax3.transAxes, fontsize=8, va='top',
                     bbox=dict(boxstyle='round,pad=0.4',
                               fc='#fffde7', alpha=0.85, ec='#e0e0e0'))

        ax3.set_xlabel('Mann-Kendall Z-Score', fontsize=11, fontweight='bold')
        ax3.set_ylabel('Pixel Count', fontsize=11, fontweight='bold')
        ax3.set_title('Trend Map Distribution  (Mann-Kendall Z-Score)',
                      fontsize=13, fontweight='bold', pad=10)
        ax3.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        # ── Panel 4: Sen's slope histogram ────────────────────────────────
        ax4 = self.axes[1, 1]
        vs  = self._valid(self.results['slope_map'])

        if len(vs):
            ax4.hist(vs, bins=100, color='#e65100',
                     edgecolor='none', alpha=0.80, linewidth=0.4)
            ax4.axvline(0, color='#c62828', ls='--', lw=2.0,
                        label='Zero change')
            ax4.axvline(float(np.median(vs)), color='#00695c',
                        ls='--', lw=2.0,
                        label=f'Median = {np.median(vs):.5f}')
            ax4.legend(fontsize=8, framealpha=0.9, edgecolor='#cccccc')
            ax4.text(0.02, 0.97,
                     f"n = {len(vs):,}\n"
                     f"Min  = {np.min(vs):.4f}\n"
                     f"Max  = {np.max(vs):.4f}\n"
                     f"Mean = {np.mean(vs):.5f}\n"
                     f"Std  = {np.std(vs):.5f}",
                     transform=ax4.transAxes, fontsize=8, va='top',
                     bbox=dict(boxstyle='round,pad=0.4',
                               fc='#fffde7', alpha=0.85, ec='#e0e0e0'))

        ax4.set_xlabel("Sen's Slope  (units yr⁻¹)", fontsize=11,
                       fontweight='bold')
        ax4.set_ylabel('Pixel Count', fontsize=11, fontweight='bold')
        ax4.set_title("Rate-of-Change Distribution  (Sen's Slope)",
                      fontsize=13, fontweight='bold', pad=10)
        ax4.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        # ── Panel 5: Lag-1 ACF histogram ─────────────────────────────────
        ax5  = self.axes[1, 2]
        vacf = self._valid(self.results.get('autocorr_map',
                           np.array([NODATA_VALUE])))
        corr_applied = self.results.get('autocorr_correction', False)

        if len(vacf):
            ax5.hist(vacf, bins=60, color='#6a1b9a',
                     edgecolor='none', alpha=0.80, linewidth=0.4)
            ax5.axvline(0, color='#c62828', ls='--', lw=2.0,
                        label='No autocorrelation (ρ₁ = 0)')
            ax5.axvline( 0.1, color='#e65100', ls=':', lw=1.2)
            ax5.axvline(-0.1, color='#e65100', ls=':', lw=1.2,
                        label='|ρ₁| = 0.10 threshold')
            med_acf = float(np.median(vacf))
            pct_pos = float(np.mean(vacf > 0) * 100)
            ax5.axvline(med_acf, color='#00695c', ls='--', lw=2.0,
                        label=f'Median ρ₁ = {med_acf:.3f}')
            ax5.legend(fontsize=8, framealpha=0.9, edgecolor='#cccccc')
            ax5.text(0.02, 0.97,
                     f"n = {len(vacf):,}\n"
                     f"Mean   = {np.mean(vacf):.3f}\n"
                     f"Median = {med_acf:.3f}\n"
                     f"Std    = {np.std(vacf):.3f}\n"
                     f"% positive = {pct_pos:.1f}%\n"
                     f"Correction {'✓ ON' if corr_applied else '✗ OFF'}",
                     transform=ax5.transAxes, fontsize=8, va='top',
                     bbox=dict(boxstyle='round,pad=0.4',
                               fc='#f3e5f5', alpha=0.90, ec='#ce93d8'))
            ax5.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        ax5.set_xlabel('Lag-1 Spearman ACF  (ρ₁)', fontsize=11,
                       fontweight='bold')
        ax5.set_ylabel('Pixel Count', fontsize=11, fontweight='bold')
        title5 = ('Lag-1 Autocorrelation  [Hamed & Rao correction ✓]'
                  if corr_applied else
                  'Lag-1 Autocorrelation  (ACF map)')
        ax5.set_title(title5, fontsize=13, fontweight='bold', pad=10)

        # ── Panel 6: Data Quality Overview [0,2] ─────────────────────────
        ax6 = self.axes[0, 2]
        completeness_map = self.results.get('completeness_map')
        outlier_map      = self.results.get('outlier_map')
        n_ts             = len(years)

        if completeness_map is not None:
            vc = self._valid(completeness_map)
            if len(vc):
                bins_c = np.arange(0, n_ts + 2) - 0.5
                ax6.hist(vc, bins=bins_c, color='#2e7d32',
                         edgecolor='white', linewidth=0.4, alpha=0.85,
                         label='Completeness')
                full_pct = float(np.mean(vc == n_ts) * 100)
                ax6.text(0.02, 0.97,
                         f"n = {len(vc):,}\n"
                         f"Full coverage : {full_pct:.1f} %\n"
                         f"Mean obs      : {np.mean(vc):.1f} / {n_ts}",
                         transform=ax6.transAxes, fontsize=8, va='top',
                         bbox=dict(boxstyle='round,pad=0.4',
                                   fc='#e8f5e9', alpha=0.90, ec='#a5d6a7'))

        if outlier_map is not None:
            vo = self._valid(outlier_map)
            if len(vo):
                ax6b = ax6.twinx()
                ax6b.hist(vo, bins=np.arange(0, int(np.max(vo)) + 2) - 0.5,
                          color='#e65100', edgecolor='white',
                          linewidth=0.4, alpha=0.50, label='Outlier count')
                ax6b.set_ylabel('Outlier count  (pixels)',
                                fontsize=9, color='#e65100')
                ax6b.tick_params(axis='y', labelcolor='#e65100', labelsize=8)
                clean_pct = float(np.mean(vo == 0) * 100)
                ax6.text(0.98, 0.97,
                         f"Clean pixels : {clean_pct:.1f} %",
                         transform=ax6.transAxes, fontsize=8,
                         va='top', ha='right',
                         bbox=dict(boxstyle='round,pad=0.4',
                                   fc='#fff3e0', alpha=0.90, ec='#ffcc80'))

        ax6.set_xlabel('Observation Count', fontsize=11, fontweight='bold')
        ax6.set_ylabel('Pixel Count  (completeness)', fontsize=9,
                       color='#2e7d32')
        ax6.tick_params(axis='y', labelcolor='#2e7d32', labelsize=8)
        ax6.set_title('Data Quality Overview', fontsize=13,
                      fontweight='bold', pad=10)
        ax6.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        self.figure.tight_layout()

        # ── MAST logo (top-left corner) ───────────────────────────────────────
        self._draw_logo(self.figure)

        self.canvas.draw()

    def _draw_logo(self, fig, small=False):
        """Draws the MAST icon in the top-left corner.

        Parameters
        ----------
        fig   : matplotlib.figure.Figure
        small : bool
            True  → small size for individual panel figures.
            False → standard size for the combined 4-panel figure.
        """
        import matplotlib.patches as mpatches
        from matplotlib.transforms import blended_transform_factory

        if small:
            # Individual panel (7 × 5.5 in)
            rect     = [0.004, 0.950, 0.090, 0.044]
            fs_mast  = 7.0
            lw_box   = 1.0
            lw_line  = 0.9
            ms_dot   = 1.6
            lw_arrow = 0.8
            icon_x   = [0.9, 1.7, 2.5, 3.3]
            icon_y   = [3.0, 4.8, 4.0, 6.8]
            arr_xy   = (3.6, 7.2)
            arr_xt   = (3.1, 6.4)
            txt_x    = 6.7
        else:
            # Combined 2×3-panel (18 × 10 in)
            rect     = [0.004, 0.957, 0.055, 0.040]
            fs_mast  = 10.5
            lw_box   = 1.5
            lw_line  = 1.4
            ms_dot   = 2.2
            lw_arrow = 1.2
            icon_x   = [0.8, 1.6, 2.4, 3.2]
            icon_y   = [3.2, 4.8, 4.2, 6.8]
            arr_xy   = (3.5, 7.3)
            arr_xt   = (3.0, 6.5)
            txt_x    = 6.6

        la = fig.add_axes(rect)
        la.set_xlim(0, 10)
        la.set_ylim(0, 10)
        la.axis('off')
        la.set_clip_on(False)

        # ── Background: dark navy rounded rectangle ───────────────────────
        la.add_patch(mpatches.FancyBboxPatch(
            (0.15, 0.15), 9.70, 9.70,
            boxstyle="round,pad=0.6",
            facecolor='#0d1b5e', edgecolor='#4a90d9',
            linewidth=lw_box, zorder=1,
            transform=la.transData, clip_on=False))

        # ── Trend line icon (left side) ──────────────────────────────────
        la.plot(icon_x, icon_y, '-', color='#64b5f6', lw=lw_line, zorder=3,
                solid_capstyle='round', clip_on=False)
        la.plot(icon_x, icon_y, 'o', color='#90caf9', ms=ms_dot, zorder=4,
                clip_on=False)
        la.annotate('', xy=arr_xy, xytext=arr_xt,
                    arrowprops=dict(arrowstyle='->', color='#42a5f5',
                                   lw=lw_arrow), zorder=4,
                    annotation_clip=False)

        # ── 'MAST' label — fully visible in box with clip_on=False ─────
        la.text(txt_x, 5.0, 'MAST',
                ha='center', va='center',
                fontsize=fs_mast, fontweight='bold',
                color='#ffffff', zorder=5,
                clip_on=False,
                transform=la.transData)

    # ── Chart saving (publication quality) ────────────────────────────────

    def _save_figures(self):
        """Saves charts to the output folder as high-resolution PNG/JPG files."""
        fmt_text = self.fmt_combo.currentText()   # e.g. "PNG (300 DPI)"
        ext  = 'png' if fmt_text.startswith('PNG') else 'jpg'
        dpi  = 600 if '600' in fmt_text else 300

        # Output folder: use output_path if available, otherwise prompt the user
        save_dir = self.output_path
        if not save_dir or not os.path.isdir(save_dir):
            save_dir = QFileDialog.getExistingDirectory(
                self, "Select Folder to Save Charts")
            if not save_dir:
                return

        saved = []

        # ── 1) All panels as a single combined file ───────────────────────
        combined_path = os.path.join(save_dir,
                                     f"mast_charts_combined.{ext}")
        save_kwargs = dict(
            dpi=dpi, bbox_inches='tight',
            facecolor='white', edgecolor='none', format=ext)
        if ext == 'png':   # JPEG does not support metadata
            save_kwargs['metadata'] = {
                'Title':   f'MAST {PLUGIN_VERSION} — Statistical Charts',
                'Author':  'Ömer K. ÖRÜCÜ — MAST Plugin',
                'Subject': "Mann-Kendall & Sen's Slope Trend Analysis",
                'Software': f'MAST {PLUGIN_VERSION}',
            }
        self.figure.savefig(combined_path, **save_kwargs)
        saved.append(os.path.basename(combined_path))

        # ── 2) Each panel as a separate file ──────────────────────────────
        panel_info = [
            (self.axes[0, 0], 'mast_panel1_timeseries'),
            (self.axes[0, 1], 'mast_panel2_trend_pie'),
            (self.axes[0, 2], 'mast_panel6_data_quality'),
            (self.axes[1, 0], 'mast_panel3_zscore_hist'),
            (self.axes[1, 1], 'mast_panel4_slope_hist'),
            (self.axes[1, 2], 'mast_panel5_acf_hist'),
        ]

        for ax, stem in panel_info:
            # Create a new figure for a single axis (leaves original intact)
            fig_single, ax_single = plt.subplots(1, 1, figsize=(7, 5.5))
            ax_single.set_visible(False)

            # Most reliable approach for copying axis content to a new figure:
            # single-panel re-draw
            self._plot_single_panel(ax_single, ax, fig_single)

            out_path = os.path.join(save_dir, f"{stem}.{ext}")
            fig_single.savefig(
                out_path,
                dpi=dpi,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none',
                format=ext)
            plt.close(fig_single)
            saved.append(os.path.basename(out_path))

        QMessageBox.information(
            self, "Charts Saved",
            f"Charts saved successfully ({ext.upper()}, {dpi} DPI).\n\n"
            f"Saved files:\n" +
            "\n".join(f"  • {s}" for s in saved) +
            f"\n\nFolder:\n{save_dir}")

    def _plot_single_panel(self, ax_new, ax_orig, fig_new):
        """Redraws the content of a single axis in a new figure."""
        # Retrieve basic properties from the original axis
        title  = ax_orig.get_title()
        xlabel = ax_orig.get_xlabel()
        ylabel = ax_orig.get_ylabel()

        # Identify the panel from its title and redraw accordingly
        ax_new.set_visible(True)
        years  = self.results['years']
        arrays = self.results['arrays']
        st     = self.results['statistics']

        if 'Time Series' in title:
            means = [float(np.ma.mean(self._mask(a))) for a in arrays]
            ax_new.plot(years, means, 'o-', lw=2.5, ms=7,
                        color='#1565c0', label='Regional mean',
                        markerfacecolor='white', markeredgewidth=2.0)
            from scipy import stats as sp2
            sl, ic, rv, *_ = sp2.linregress(years, means)
            ax_new.plot(years, [sl * y + ic for y in years],
                        '--', color='#c62828', lw=1.8,
                        label=f'OLS: {sl:+.4f} yr⁻¹  (R²={rv**2:.3f})')
            ax_new.legend(fontsize=9, framealpha=0.9)
            ax_new.grid(True, alpha=0.3, linewidth=0.6)

        elif 'Trend Direction' in title:
            raw = [
                (st['increasing_trend'], 'Increasing', '#2e7d32', 0.06),
                (st['decreasing_trend'], 'Decreasing', '#c62828', 0.06),
                (st['no_trend'],         'No Trend',   '#757575', 0.00),
            ]
            flt = [(s, l, c, e) for s, l, c, e in raw if s > 0]
            if flt:
                sz, lb, co, ex = zip(*flt)
                ax_new.pie(sz, explode=ex, labels=lb, colors=co,
                           autopct='%1.1f %%', shadow=False, startangle=90,
                           textprops={'fontsize': 10},
                           wedgeprops={'linewidth': 0.8, 'edgecolor': 'white'})

        elif 'Z-Score' in title:
            vz = self._valid(self.results['trend_map'])
            if len(vz):
                ax_new.hist(vz, bins=100, color='#1565c0',
                            edgecolor='none', alpha=0.80)
                ax_new.axvline(0,      color='#c62828', ls='--', lw=2.0,
                               label='No trend (Z=0)')
                ax_new.axvline(-1.96,  color='#e65100', ls=':',  lw=1.5,
                               label='α=0.05 (Z=±1.96)')
                ax_new.axvline( 1.96,  color='#e65100', ls=':',  lw=1.5)
                ax_new.axvline(float(np.median(vz)), color='#00695c',
                               ls='--', lw=2.0,
                               label=f'Median={np.median(vz):.3f}')
                ax_new.legend(fontsize=8, framealpha=0.9)
                ax_new.text(0.02, 0.97,
                            f"n={len(vz):,}  Mean={np.mean(vz):.3f}  "
                            f"Std={np.std(vz):.3f}",
                            transform=ax_new.transAxes, fontsize=8, va='top',
                            bbox=dict(boxstyle='round,pad=0.4',
                                      fc='#fffde7', alpha=0.85, ec='#e0e0e0'))
                ax_new.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        elif "Sen" in title:
            vs = self._valid(self.results['slope_map'])
            if len(vs):
                ax_new.hist(vs, bins=100, color='#e65100',
                            edgecolor='none', alpha=0.80)
                ax_new.axvline(0, color='#c62828', ls='--', lw=2.0,
                               label='Zero change')
                ax_new.axvline(float(np.median(vs)), color='#00695c',
                               ls='--', lw=2.0,
                               label=f'Median={np.median(vs):.5f}')
                ax_new.legend(fontsize=8, framealpha=0.9)
                ax_new.text(0.02, 0.97,
                            f"n={len(vs):,}  Mean={np.mean(vs):.5f}  "
                            f"Std={np.std(vs):.5f}",
                            transform=ax_new.transAxes, fontsize=8, va='top',
                            bbox=dict(boxstyle='round,pad=0.4',
                                      fc='#fffde7', alpha=0.85, ec='#e0e0e0'))
                ax_new.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        elif 'Autocorrelation' in title or 'ACF' in title:
            vacf = self._valid(self.results.get('autocorr_map',
                               np.array([NODATA_VALUE])))
            corr_applied = self.results.get('autocorr_correction', False)
            if len(vacf):
                ax_new.hist(vacf, bins=60, color='#6a1b9a',
                            edgecolor='none', alpha=0.80)
                ax_new.axvline(0,    color='#c62828', ls='--', lw=2.0,
                               label='ρ₁ = 0')
                ax_new.axvline( 0.1, color='#e65100', ls=':', lw=1.2)
                ax_new.axvline(-0.1, color='#e65100', ls=':', lw=1.2,
                               label='|ρ₁| = 0.10')
                med_acf = float(np.median(vacf))
                ax_new.axvline(med_acf, color='#00695c', ls='--', lw=2.0,
                               label=f'Median={med_acf:.3f}')
                ax_new.legend(fontsize=8, framealpha=0.9)
                ax_new.text(0.02, 0.97,
                            f"n={len(vacf):,}  Mean={np.mean(vacf):.3f}  "
                            f"Correction={'ON' if corr_applied else 'OFF'}",
                            transform=ax_new.transAxes, fontsize=8, va='top',
                            bbox=dict(boxstyle='round,pad=0.4',
                                      fc='#f3e5f5', alpha=0.90, ec='#ce93d8'))
                ax_new.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        elif 'Data Quality' in title:
            n_ts             = len(self.results['years'])
            completeness_map = self.results.get('completeness_map')
            outlier_map      = self.results.get('outlier_map')
            if completeness_map is not None:
                vc = self._valid(completeness_map)
                if len(vc):
                    ax_new.hist(vc, bins=np.arange(0, n_ts + 2) - 0.5,
                                color='#2e7d32', edgecolor='white',
                                linewidth=0.4, alpha=0.85)
                    full_pct = float(np.mean(vc == n_ts) * 100)
                    ax_new.text(0.02, 0.97,
                                f"n={len(vc):,}  Full coverage: {full_pct:.1f}%",
                                transform=ax_new.transAxes, fontsize=8, va='top',
                                bbox=dict(boxstyle='round,pad=0.4',
                                          fc='#e8f5e9', alpha=0.90, ec='#a5d6a7'))
            if outlier_map is not None:
                vo = self._valid(outlier_map)
                if len(vo):
                    ax6b = ax_new.twinx()
                    ax6b.hist(vo, bins=np.arange(0, int(np.max(vo)) + 2) - 0.5,
                              color='#e65100', edgecolor='white',
                              linewidth=0.4, alpha=0.50)
                    ax6b.set_ylabel('Outlier count', fontsize=9, color='#e65100')
                    ax6b.tick_params(axis='y', labelcolor='#e65100', labelsize=8)
            ax_new.set_ylabel('Pixel Count', fontsize=9, color='#2e7d32')
            ax_new.tick_params(axis='y', labelcolor='#2e7d32', labelsize=8)
            ax_new.grid(True, alpha=0.3, linewidth=0.6, axis='y')

        ax_new.set_title(title, fontsize=13, fontweight='bold', pad=10)
        ax_new.set_xlabel(xlabel, fontsize=11, fontweight='bold')
        ax_new.set_ylabel(ylabel, fontsize=11, fontweight='bold')

        # MAST logo (top-left) — small size for individual panels
        self._draw_logo(fig_new, small=True)

        fig_new.tight_layout()


# =============================================================================
#  QGIS PLUGIN WRAPPER
# =============================================================================

class MASTPlugin:
    """QGIS plugin entry point — registers menu action and toolbar button."""

    def __init__(self, iface):
        self.iface  = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path)
        self.action = QAction(
            icon,
            PLUGIN_NAME,
            self.iface.mainWindow())
        self.action.setToolTip(
            f"{PLUGIN_NAME} {PLUGIN_VERSION}\n{PLUGIN_TITLE}\n"
            "Non-parametric spatio-temporal trend analysis for raster "
            "time series (Mann-Kendall + Sen's slope)")
        self.action.triggered.connect(self.run)

        # Menu
        self.iface.addPluginToRasterMenu(PLUGIN_NAME, self.action)
        # Toolbar
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginRasterMenu(PLUGIN_NAME, self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if not SCIPY_AVAILABLE:
            QMessageBox.critical(
                self.iface.mainWindow(),
                f"{PLUGIN_NAME} — Missing Dependencies",
                "MAST requires scipy and matplotlib.\n\n"
                "Install via the OSGeo4W Shell:\n"
                "  python -m pip install scipy matplotlib\n\n"
                "Restart QGIS after installation.")
            return
        self.dialog = MASTDialog()
        self.dialog.exec()


# =============================================================================
#  MODULE-LEVEL FACTORY  (fallback — primary factory is in __init__.py)
# =============================================================================

def classFactory(iface):
    """Called by QGIS when the plugin is loaded."""
    return MASTPlugin(iface)
