# MAST - Mann-Kendall And Sen's Slope Trend Analyzer

A QGIS 4.0+ plugin for **non-parametric spatio-temporal trend analysis** of raster time series data using the Mann-Kendall test and Theil-Sen slope estimator.

![QGIS](https://img.shields.io/badge/QGIS-4.0%2B-green)
![License](https://img.shields.io/badge/License-GPLv2%2B-blue)
![Python](https://img.shields.io/badge/Python-3.12-yellow)

> **Note:** This is an anonymized version of the plugin prepared for double-blind peer review. Author, institutional affiliation, and repository information have been removed in accordance with journal submission guidelines.

## Features

- **Mann-Kendall Z-score trend map** - Monotonic trend direction and strength
- **P-value significance map** - Two-tailed statistical significance
- **Sen's slope map** - Rate of change (units/year)
- **Cumulative change map** - Total change from first to last observation
- **Statistical summary** - JSON report with full analysis results
- **Four-panel visualization dashboard** - Interactive matplotlib-based charts
- Robust NoData handling and CRS preservation
- LZW-compressed GeoTIFF output

## Installation

### From ZIP

1. Obtain the plugin ZIP provided as supplementary material to the manuscript
2. In QGIS: **Plugins > Manage and Install Plugins > Install from ZIP**
3. Select the downloaded ZIP file

### Manual

1. Extract the archive
2. Copy the `mast` folder to your QGIS plugins directory:
   - **Windows:** `%APPDATA%\QGIS\QGIS4\profiles\default\python\plugins\`
   - **Linux:** `~/.local/share/QGIS/QGIS4/profiles/default/python/plugins/`
   - **macOS:** `~/Library/Application Support/QGIS/QGIS4/profiles/default/python/plugins/`
3. Restart QGIS and enable the plugin in **Plugins > Manage and Install Plugins**

### Dependencies

MAST requires **SciPy** and **Matplotlib**. Install via the OSGeo4W Shell (Windows) or your system terminal:

```bash
python -m pip install scipy matplotlib
```

## Usage

1. Open QGIS and load your raster layers (one per time step)
2. Click the **MAST** icon in the Raster toolbar, or go to **Raster > MAST**
3. Add raster layers to the analysis list and assign year labels
4. Select an output directory
5. Click **Run Analysis**

## Output

| File | Description |
|------|-------------|
| `trend_map_zscore.tif` | Mann-Kendall Z-score (float32) |
| `p_value.tif` | Two-tailed p-value, 0-1 (float32) |
| `sens_slope.tif` | Sen's slope, units/year (float32) |
| `total_change.tif` | Last - First value (float32) |
| `statistics.json` | Full summary report |

## References

- Mann, H. B. (1945). Nonparametric tests against trend. *Econometrica*, 13(3), 245-259.
- Kendall, M. G. (1975). *Rank Correlation Methods* (4th ed.). Charles Griffin, London.
- Sen, P. K. (1968). Estimates of the regression coefficient based on Kendall's tau. *JASA*, 63(324), 1379-1389.
- Theil, H. (1950). A rank-invariant method of linear and polynomial regression analysis. *Proc. Royal Netherlands Academy of Arts and Sciences*, 53, 386-392.

## Author

*Author information withheld for double-blind peer review.*

## License

This project is licensed under the GNU General Public License v2 or later - see the [LICENSE](LICENSE) file for details.
