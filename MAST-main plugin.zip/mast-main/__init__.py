# -*- coding: utf-8 -*-
"""
MAST — Mann-Kendall And Sen's Slope Trend Analyzer
====================================================
A QGIS 4.0 plugin for non-parametric spatio-temporal
trend analysis of raster time series data.

Version : 1.0.0
Author  : [ANONYMIZED FOR PEER REVIEW]
"""


def classFactory(iface):
    from .mast_plugin import MASTPlugin
    return MASTPlugin(iface)
