<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories">
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2"
        zoomedInResamplingMethod="nearestNeighbour"
        zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer opacity="1" alphaBand="-1" type="singlebandpseudocolor"
                    band="1" nodataColor="">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>MinMax</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <!--
          İki Kuyruklu p-değeri  |  Anlamlılık Sınıfları
          ──────────────────────────────────────────────────
          Koyu Mor     0.000–0.010  →  Çok yüksek anlamlılık  (α = 0.01)
          Mor          0.010–0.050  →  Anlamlı  (α = 0.05)  ← temel eşik
          Sarı-Turuncu 0.050–0.100  →  Marjinal  (α = 0.10)
          Açık Gri     0.100–0.500  →  Anlamsız
          Beyaz        0.500–1.000  →  Tamamen anlamsız
        -->
        <colorrampshader colorRampType="DISCRETE" clip="0"
          classificationMode="1" maximumValue="1" minimumValue="0"
          labelPrecision="3">
          <colorramp name="[source]" type="gradient">
            <Option type="Map">
              <Option name="color1" type="QString" value="84,1,68,255"/>
              <Option name="color2" type="QString" value="255,255,255,255"/>
              <Option name="direction" type="QString" value="ccw"/>
              <Option name="discrete" type="QString" value="0"/>
              <Option name="rampType" type="QString" value="gradient"/>
            </Option>
          </colorramp>
          <item alpha="255" value="0.001" color="#40004b"
                label="0.000 – 0.001  |  p &lt; 0.001  (Çok yüksek anlamlı)"/>
          <item alpha="255" value="0.010" color="#762a83"
                label="0.001 – 0.010  |  p &lt; 0.010  (α = 0.01)"/>
          <item alpha="255" value="0.050" color="#9970ab"
                label="0.010 – 0.050  |  p &lt; 0.050  (α = 0.05  ★)"/>
          <item alpha="255" value="0.100" color="#f1a340"
                label="0.050 – 0.100  |  p &lt; 0.100  (Marjinal)"/>
          <item alpha="255" value="0.200" color="#fee0b6"
                label="0.100 – 0.200  |  Anlamsız"/>
          <item alpha="255" value="0.500" color="#d9d9d9"
                label="0.200 – 0.500  |  Anlamsız"/>
          <item alpha="255" value="1.000" color="#f7f7f7"
                label="0.500 – 1.000  |  Tamamen anlamsız"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeOn="0" grayscaleMode="0" invertColors="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
