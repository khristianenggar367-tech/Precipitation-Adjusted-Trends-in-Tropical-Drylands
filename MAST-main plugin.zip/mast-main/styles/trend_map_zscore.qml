<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories">
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2"
        zoomedInResamplingMethod="nearestNeighbour"
        zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer opacity="1" alphaBand="-1" type="singlebandpseudocolor"
                    band="1" nodataColor="">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>MinMax</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <!--
          Mann-Kendall Z-Score  |  Diverjant Renk Skalası
          ─────────────────────────────────────────────────
          Koyu Mavi  →  Güçlü azalış trendi  (Z < −2.58, α = 0.01)
          Mavi       →  Anlamlı azalış        (−2.58 … −1.96, α = 0.05)
          Açık Mavi  →  Zayıf azalış          (−1.96 … 0)
          Sarı/Krem  →  Trend yok             (Z ≈ 0)
          Turuncu    →  Zayıf artış           (0 … +1.96)
          Kırmızı    →  Anlamlı artış         (+1.96 … +2.58, α = 0.05)
          Koyu Kırmızı → Güçlü artış trendi  (Z > +2.58, α = 0.01)
        -->
        <colorrampshader colorRampType="INTERPOLATED" clip="0"
          classificationMode="1" maximumValue="4" minimumValue="-4"
          labelPrecision="2">
          <colorramp name="[source]" type="gradient">
            <Option type="Map">
              <Option name="color1" type="QString" value="5,48,97,255"/>
              <Option name="color2" type="QString" value="103,0,31,255"/>
              <Option name="direction" type="QString" value="ccw"/>
              <Option name="discrete" type="QString" value="0"/>
              <Option name="rampType" type="QString" value="gradient"/>
            </Option>
          </colorramp>
          <item alpha="255" value="-4.0"  color="#053061"
                label="≤ −4.0  |  Çok güçlü azalış"/>
          <item alpha="255" value="-2.58" color="#2166ac"
                label="−2.58  |  Yüksek anlamlı azalış  (α = 0.01)"/>
          <item alpha="255" value="-1.96" color="#74add1"
                label="−1.96  |  Anlamlı azalış  (α = 0.05)"/>
          <item alpha="255" value="-1.28" color="#abd9e9"
                label="−1.28  |  Zayıf azalış  (α = 0.20)"/>
          <item alpha="255" value="-0.50" color="#e0f3f8"
                label="−0.50  |  Çok zayıf azalış"/>
          <item alpha="255" value="0.0"   color="#ffffbf"
                label="0.00   |  Trend yok"/>
          <item alpha="255" value="0.50"  color="#fee090"
                label="+0.50  |  Çok zayıf artış"/>
          <item alpha="255" value="1.28"  color="#fdae61"
                label="+1.28  |  Zayıf artış  (α = 0.20)"/>
          <item alpha="255" value="1.96"  color="#f46d43"
                label="+1.96  |  Anlamlı artış  (α = 0.05)"/>
          <item alpha="255" value="2.58"  color="#d73027"
                label="+2.58  |  Yüksek anlamlı artış  (α = 0.01)"/>
          <item alpha="255" value="4.0"   color="#67001f"
                label="≥ +4.0  |  Çok güçlü artış"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeOn="0" grayscaleMode="0" invertColors="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
