<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories">
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2"
        zoomedInResamplingMethod="nearestNeighbour"
        zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer opacity="1" alphaBand="-1" type="singlebandpseudocolor"
                    band="1" nodataColor="">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>StdDev</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <!--
          Sen Eğimi (birim yr⁻¹)  |  Diverjant Renk Skalası
          ──────────────────────────────────────────────────────
          Min değer 2σ kırpma ile otomatik belirlenir.
          Kahverengi  →  Negatif eğim  (azalış, kuruluğa/kayba işaret)
          Krem/Beyaz  →  Sıfır değişim
          Koyu Yeşil  →  Pozitif eğim  (artış, ıslak/kazanç)

          Not: Rasterın gerçek min-max değerine göre
          QGIS otomatik olarak bu renkleri ölçekler.
        -->
        <colorrampshader colorRampType="INTERPOLATED" clip="0"
          classificationMode="2" maximumValue="0.1" minimumValue="-0.1"
          labelPrecision="4">
          <colorramp name="[source]" type="gradient">
            <Option type="Map">
              <Option name="color1" type="QString" value="84,48,5,255"/>
              <Option name="color2" type="QString" value="0,60,48,255"/>
              <Option name="direction" type="QString" value="ccw"/>
              <Option name="discrete" type="QString" value="0"/>
              <Option name="rampType" type="QString" value="gradient"/>
            </Option>
          </colorramp>
          <!-- Değerler veri aralığına göre QGIS tarafından yeniden ölçeklenir -->
          <item alpha="255" value="-0.100" color="#543005"
                label="Min  |  Güçlü negatif eğim (azalış)"/>
          <item alpha="255" value="-0.050" color="#8c510a"
                label="       |  Orta negatif"/>
          <item alpha="255" value="-0.020" color="#bf812d"
                label="       |  Hafif negatif"/>
          <item alpha="255" value="-0.005" color="#dfc27d"
                label="       |  Çok hafif negatif"/>
          <item alpha="255" value="0.000"  color="#f5f5f5"
                label="0.000  |  Değişim yok"/>
          <item alpha="255" value="0.005"  color="#c7eae5"
                label="       |  Çok hafif pozitif"/>
          <item alpha="255" value="0.020"  color="#80cdc1"
                label="       |  Hafif pozitif"/>
          <item alpha="255" value="0.050"  color="#35978f"
                label="       |  Orta pozitif"/>
          <item alpha="255" value="0.100"  color="#003c30"
                label="Max  |  Güçlü pozitif eğim (artış)"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeOn="0" grayscaleMode="0" invertColors="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
