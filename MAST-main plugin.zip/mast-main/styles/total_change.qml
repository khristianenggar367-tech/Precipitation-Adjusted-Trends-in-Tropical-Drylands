<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories">
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2"
        zoomedInResamplingMethod="nearestNeighbour"
        zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer opacity="1" alphaBand="-1" type="singlebandpseudocolor"
                    band="1" nodataColor="">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>StdDev</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <!--
          Toplam Değişim  (Son − İlk)  |  Diverjant Renk Skalası
          ──────────────────────────────────────────────────────────
          Mor/Kahverengi  →  Negatif net değişim  (kayıp)
          Beyaz           →  Değişim yok
          Yeşil           →  Pozitif net değişim  (kazanç)

          Değerler gerçek raster min-max'a göre ölçeklenir.
        -->
        <colorrampshader colorRampType="INTERPOLATED" clip="0"
          classificationMode="2" maximumValue="1" minimumValue="-1"
          labelPrecision="3">
          <colorramp name="[source]" type="gradient">
            <Option type="Map">
              <Option name="color1" type="QString" value="64,0,75,255"/>
              <Option name="color2" type="QString" value="0,68,27,255"/>
              <Option name="direction" type="QString" value="ccw"/>
              <Option name="discrete" type="QString" value="0"/>
              <Option name="rampType" type="QString" value="gradient"/>
            </Option>
          </colorramp>
          <item alpha="255" value="-1.00" color="#40004b"
                label="Min  |  Büyük kayıp  (Son &lt; İlk)"/>
          <item alpha="255" value="-0.60" color="#762a83"
                label="       |  Orta kayıp"/>
          <item alpha="255" value="-0.30" color="#af8dc3"
                label="       |  Hafif kayıp"/>
          <item alpha="255" value="-0.10" color="#e7d4e8"
                label="       |  Çok hafif kayıp"/>
          <item alpha="255" value="0.00"  color="#f7f7f7"
                label="0.000  |  Değişim yok"/>
          <item alpha="255" value="0.10"  color="#d9f0d3"
                label="       |  Çok hafif artış"/>
          <item alpha="255" value="0.30"  color="#7fbf7b"
                label="       |  Hafif artış"/>
          <item alpha="255" value="0.60"  color="#1b7837"
                label="       |  Orta artış"/>
          <item alpha="255" value="1.00"  color="#00441b"
                label="Max  |  Büyük artış  (Son &gt; İlk)"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeOn="0" grayscaleMode="0" invertColors="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
